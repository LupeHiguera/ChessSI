# Historical PeSTO RFP evidence

This package supports the separate cumulative RFP-removal report: **Failed**, H0 at 1,376 games on the historical PeSTO baseline. The explicit AI review is `ChessSI-astra/engines/rfp-removal-worktree/engines/rfp-removal-disposition/manual-review.json`; it preserves the extractor's unresolved status and unknown supervision metadata. It is not a claim of human review. The failed source change was reverted in commit `f3464befa4d3dc58489b5d48890935a00721e0ae`; 35 perft and 17 RFP cases pass, bench 276006, and the rebuilt binary matches the original baseline.

`ChessSI-astra/` mirrors original project-relative paths. Original files are copied byte for byte: paths inside manifests and observations remain historical data. The original 18 games and continuation are one trial; the earlier 146-game LTC comparison is separate. No result here transfers to NNUE main.

## Contents and integrity

- Complete original initial/terminal snapshots and supporting validation records; full continuation and observer directories, including checkpoint and terminal raw/logical snapshots.
- All files addressed by included snapshot manifests, including engine binaries. Hash-only external artifacts, such as the shared book, remain external where the original manifest records no archived copy.
- Replay helpers, pinned python-chess sources, and the pinned-source SPRT calculator with its sources, adapters and licence.
- Accepted-main correctness/bench records under `ChessSI-astra/engines/rfp-ltc-result-worktree/engines/accepted-main-validation/`; these concern publication baseline `d4e26f5`, not the historical match binaries.
- `inventory.json`: staged relative paths, sizes and SHA-256 values, excluding the inventory itself. Verify against the included final inventory before reproduction.

Excluded: unrelated `history-provenance-proposal*.md`, standalone expendable validated/sanitizer executables outside snapshots, and Python bytecode/cache directories. Validation logs, scripts and metadata remain.

## Isolated reproduction with unchanged tools

Use a fresh isolated Linux/WSL environment. Do **not** overlay this archive onto an existing project or execute its observer, resume or launch scripts. Place the contents of `ChessSI-astra/` at the exact canonical directory below:

```bash
repro_root=/mnt/c/Users/Lupe/CLionProjects/ChessSI-astra
run="$repro_root/engines/rfp-removal-worktree/engines"
watch="$run/rfp-removal-watch-01"
audit_out="$repro_root/engines/replay-audit"
```

Use the recorded Python environment where possible, leave assertions enabled, and provide CPU 19. The unchanged auditor imports helpers from its hardcoded root before argument parsing, requires resolved snapshot/output paths below that root, and requires affinity exactly `{19}`. Merely setting `PYTHONPATH` or symlinking the root elsewhere does not remove those restrictions. Output paths must be new.

```bash
for snapshot in \
  "$run/rfp-removal-validation/initial-snapshot" \
  "$run/rfp-removal-validation/terminal-snapshot" \
  "$watch/checkpoint-01/raw-snapshot" \
  "$watch/checkpoint-01/logical-snapshot" \
  "$watch/raw-terminal-snapshot" \
  "$watch/logical-terminal-snapshot"
do
  taskset -c 19 python3 -B "$repro_root/scripts/research/snapshot_run.py" verify "$snapshot"
done

taskset -c 19 env -u PYTHONOPTIMIZE \
  PYTHONPATH="$repro_root/engines/dependencies/python-chess" \
  python3 -B "$repro_root/engines/qsearch-validation/audit_match.py" \
  --snapshot "$watch/logical-terminal-snapshot" --output "$audit_out"

taskset -c 19 python3 -B "$repro_root/scripts/research/extract_result.py" \
  --snapshot "$watch/logical-terminal-snapshot" --terminal-state "$watch/terminal-state.json"

taskset -c 19 python3 -B "$watch/sprt-arithmetic/verify.py" \
  --audit "$audit_out" --output "$repro_root/engines/replay-sprt.json"
```

Terminal extraction exit **2** and unresolved supervision metadata are deliberately retained. Do not mask that status or edit the observation to invent a clean exit/signal history. The separate AI review applies the predeclared policy to the preserved raw decision, actual boundary crossing and complete accounting; it does not rewrite this extractor status.

The calculator requires a compatible Linux executable/runtime and executable permission; `g++` must be on PATH even without rebuilding because the verifier queries its version. The queried compiler version describes the replay environment and need not describe a supplied prebuilt calculator. This is source-level arithmetic reproduction, not equivalence to the installed match-manager binary. It checks reported count blocks, not the final acceptance decision. New JSON contains new timestamps/paths; compare bound input hashes, counts and calculations, not identical output-file hashes.

`reconcile.py` contains pure functions for reproducing the logical log from original/resumed raw UTF-8 bytes without newline normalization. Preserve `reconciliation.json` and both raw logs; the logical log is a derived accounting projection.

For another root or CPU, retain original tools/data unchanged and document a separately hashed adaptation. Terminal-state absolute archive matching also needs explicit treatment; relocation is not evidence of original process behavior.

## Licences

ChessSI/helpers retain the root MIT licence. Pinned fastchess sources retain `sprt-arithmetic/vendor/LICENSE` (MIT). Pinned python-chess 1.11.2, commit `3516d7c6c0879af724c2855fac5a304a4ef40949`, is GPL-3.0-or-later; its `LICENSE.txt` and source attribution are included. Do not describe the entire bundle as MIT-only.
