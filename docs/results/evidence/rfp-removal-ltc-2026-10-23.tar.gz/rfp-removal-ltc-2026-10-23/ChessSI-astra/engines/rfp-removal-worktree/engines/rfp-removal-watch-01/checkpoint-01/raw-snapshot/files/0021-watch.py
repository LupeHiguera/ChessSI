#!/usr/bin/env python3
"""Attach a detached, non-invasive observer to the verified existing RFP manager."""
import argparse
import datetime as dt
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import select
import subprocess
import sys
import time

ROOT = Path('/mnt/c/Users/Lupe/CLionProjects/ChessSI-astra')
WORK = ROOT / 'engines/rfp-removal-worktree'
RESUME = WORK / 'engines/rfp-removal-resume-01'
OLD = WORK / 'engines/rfp-removal-validation'
OUT = WORK / 'engines/rfp-removal-watch-01'
MANAGER = 10954
START = '73878'
BOOT = '58bc77f0-f890-4bbc-9edd-41aafb7615a3'
PLAN_SHA = 'ed000efe72aa84c6f22ba741247d8713df004125c2a8bf3ee8e8c3610e71d791'
CPUS = set(range(14,20))

def require(ok, why):
    if not ok:
        raise RuntimeError(str(why))

def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat()

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1048576), b''):
            h.update(block)
    return h.hexdigest()

def write(name, record):
    target = OUT / name
    require(target.resolve() == target and target.is_relative_to(OUT), 'Redirected output')
    with target.open('x', encoding='utf-8') as f:
        json.dump(record, f, indent=2)
        f.write('\n')

def heartbeat(record):
    path = OUT / 'heartbeat.tmp'
    path.write_text(json.dumps(record, indent=2)+'\n')
    path.replace(OUT / 'heartbeat.json')

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    sys.modules[name] = m
    exec(compile(path.read_bytes(), str(path), 'exec'), m.__dict__)
    return m

def archive_roles(folder):
    manifest = json.loads((folder / 'manifest.json').read_bytes())
    return {r['role']: folder / r['archive_path'] for r in manifest['artifacts'] if r['role'] != 'source'}

def attach():
    require(os.sched_getaffinity(0) == {19} and sys.flags.optimize == 0, 'Observer must use unoptimized Python on CPU19')
    require(Path('/proc/sys/kernel/random/boot_id').read_text().strip() == BOOT, 'Different WSL boot')
    require(sha(RESUME / 'launch-plan.json') == PLAN_SHA, 'Resume launch plan changed')
    plan = json.loads((RESUME / 'launch-plan.json').read_bytes())
    for filename, digest in plan['pinned_sha256'].items():
        require(sha(filename) == digest, 'Frozen input changed: ' + filename)
    helper = module('original_identity', OLD / 'run_match.py')
    rec = module('recovered_reconcile', RESUME / 'reconcile.py')
    expected = json.loads((RESUME / 'startup.json').read_bytes())['manager']
    require(expected['pid'] == MANAGER and expected['start_ticks'] == START and expected['pgid'] == expected['sid'] == MANAGER, 'Unexpected original manager record')
    def identity_check():
        observed = helper.identity(MANAGER)
        for key in ('pid','start_ticks','pgid','sid','cwd','exe','argv','affinity'):
            require(observed[key] == expected[key], 'Manager identity changed: ' + key)
        require(observed['state'] not in ('Z','X'), 'Manager already terminal; use offline capture')
        require(sha(Path('/proc') / str(MANAGER) / 'exe') == plan['pinned_sha256'][expected['exe']], 'Actual manager executable changed')
        return observed
    before = identity_check()
    fd = os.pidfd_open(MANAGER,0)
    try:
        after = identity_check()
    except BaseException:
        os.close(fd)
        raise
    original = archive_roles(OLD / 'terminal-snapshot')
    prefix = original['pgn'].read_bytes()
    with (WORK / 'engines/sprt.pgn').open('rb') as f:
        require(f.read(len(prefix)) == prefix, 'Original PGN prefix changed')
    old_collector = json.loads((RESUME / 'runner-identity.json').read_bytes())['collector']
    try:
        now = helper.identity(old_collector['pid'])
        old_absent = now['start_ticks'] != old_collector['start_ticks']
    except (FileNotFoundError, ProcessLookupError):
        old_absent = True
    require(old_absent, 'Original collector still exists')
    record = {'attached_utc': utc(), 'observer': helper.identity(os.getpid()), 'boot_id': BOOT,
        'manager_before_pidfd': before, 'manager_after_pidfd': after,
        'original_collector': old_collector, 'original_collector_absent': True,
        'resume_launch_plan_sha256': PLAN_SHA, 'observer_sha256': sha(Path(__file__)),
        'startup_record_sha256': sha(RESUME / 'startup.json'),
        'runner_identity_sha256': sha(RESUME / 'runner-identity.json'),
        'original_config_sha256': sha(original['config']), 'pgn_prefix_sha256': sha(original['pgn']),
        'monitoring_gap': {'last_persisted_startup_utc': json.loads((RESUME/'startup.json').read_bytes())['observed_utc'],
            'exact_collector_exit_time': None, 'collector_exit_cause': 'unknown',
            'scope': 'Original collector absent at attachment; manager continued. No claim of continuous supervision.'},
        'manager_exit_code_available': False, 'global_signal_history': 'unknown',
        'monitor_policy': 'Observe only. Never start, stop, reconfigure or signal engines.'}
    return helper, rec, plan, original, prefix, fd, record

def env():
    e = {k: os.environ[k] for k in ('HOME','USER','LOGNAME','TMPDIR') if k in os.environ}
    e.update(PATH='/usr/local/bin:/usr/bin:/bin', LANG='C.UTF-8', LC_ALL='C.UTF-8',
        PYTHONPATH=str(ROOT / 'engines/dependencies/python-chess'),
        GIT_DIR='/mnt/c/Users/Lupe/CLionProjects/ChessSI/.git/worktrees/rfp-removal-worktree',
        GIT_WORK_TREE=str(WORK), GIT_OPTIONAL_LOCKS='0')
    return e

def capture(log, folder, plan):
    args = [sys.executable,'-B',str(ROOT/'scripts/research/snapshot_run.py'),'capture',
        '--source-root',str(WORK),'--run-dir',str(WORK),'--output',str(OUT/folder),
        '--config',str(WORK/'config.json'),'--pgn',str(WORK/'engines/sprt.pgn'),'--log',str(log),
        '--binary','candidate='+str(WORK/'engines/new'),'--binary','baseline='+str(WORK/'engines/base'),
        '--baseline',plan['baseline'],'--label','Reattached observer; '+folder,
        '--read-limit-mib','256','--copy-limit-mib','128']
    oldplan = json.loads((OLD/'launch-plan.json').read_bytes())
    for relative in sorted(oldplan['source_files_sha256']):
        args += ['--source-file',relative]
    for path in (Path(__file__),RESUME/'resume.py',RESUME/'reconcile.py',RESUME/'test_reconcile.py'):
        args += ['--source-file',str(path.relative_to(WORK))]
    with (OUT/(folder+'-capture.log')).open('x') as f:
        code = subprocess.run(args,cwd=WORK,env=env(),stdout=f,stderr=subprocess.STDOUT).returncode
    require(code == 0,'Snapshot failed: '+folder)

def terminal(helper, rec, plan, original, prefix, ended, anomalies, observer_sha):
    result = {'observed_end_utc':ended, 'manager_exit_code':None, 'manager_exit_code_reason':'Not a child of this observer',
        'signals_sent_by_observer':[], 'global_signal_history':'unknown',
        'monitoring_gap':True, 'anomalies':anomalies, 'benchmark_result':'not_assigned'}
    # Archive raw bytes even if later accounting or identity checks fail.
    capture(RESUME/'resume-raw.log','raw-terminal-snapshot',plan)
    raw = archive_roles(OUT/'raw-terminal-snapshot')
    try:
        require(sha(Path(__file__)) == observer_sha,'Observer changed')
        for filename,digest in plan['pinned_sha256'].items():
            require(sha(filename)==digest,'Frozen input drift: '+filename)
        require(raw['pgn'].read_bytes().startswith(prefix),'Final PGN prefix changed')
        initial = json.loads(original['config'].read_bytes())
        final = json.loads(raw['config'].read_bytes())
        require({k:v for k,v in initial.items() if k!='stats'} == {k:v for k,v in final.items() if k!='stats'},'Protocol drift')
        logical, provenance = rec.reconcile(original['log'].read_bytes().decode('utf-8'),raw['log'].read_bytes().decode('utf-8'))
        with (OUT/'logical.log').open('xb') as f:
            f.write(logical.encode('utf-8'))
        write('reconciliation.json',provenance)
        capture(OUT/'logical.log','logical-terminal-snapshot',plan)
        projected = archive_roles(OUT/'logical-terminal-snapshot')
        for role in ('config','pgn','binary_path:candidate','binary_path:baseline'):
            require(sha(raw[role])==sha(projected[role]),'Raw/derived snapshot mismatch: '+role)
        state = {'status':'archived','process_terminal':True,'observed_end_utc':ended,
            'signal_sent':None,'signals_sent_by_observer':[],'global_signal_history':'unknown',
            'monitoring_gap':True,'manager_exit_code':None,'binary_drift':False,
            'final_binary_hashes':{role:sha(raw['binary_path:'+role]) for role in ('candidate','baseline')},
            'archive':str(OUT/'logical-terminal-snapshot'),'raw_archive':str(OUT/'raw-terminal-snapshot'),
            'scope':'Observed nonchild termination. Unknown signal history is retained, requiring review.'}
        write('terminal-state.json',state)
        for name,args,out in (
            ('extract',[ROOT/'scripts/research/extract_result.py','--snapshot',OUT/'logical-terminal-snapshot','--terminal-state',OUT/'terminal-state.json'],'terminal-extraction.json'),
            ('audit',[ROOT/'engines/qsearch-validation/audit_match.py','--snapshot',OUT/'logical-terminal-snapshot','--output',OUT/'terminal-audit'],'terminal-audit.log')):
            with (OUT/out).open('x') as f:
                result[name+'_exit_code'] = subprocess.run([sys.executable,'-B',*map(str,args)],cwd=WORK,env=env(),stdout=f,stderr=subprocess.STDOUT).returncode
        extracted = json.loads((OUT/'terminal-extraction.json').read_bytes())
        audit = json.loads((OUT/'terminal-audit/result.json').read_bytes())
        require(audit['snapshot_manifest_sha256']==extracted['manifest_sha256'],'Audits name different snapshots')
        require(audit['audited_artifact_sha256']=={r:extracted['artifact_sha256'][r] for r in ('log','pgn','config')},'Audits use different inputs')
        result['accounting'] = rec.validate_final(audit,extracted['log_evidence'])
        result['six_counters'] = rec.validate_six_counters(final['stats']['new vs base'],json.loads((OUT/'terminal-audit/pgn-games.json').read_bytes()))
        result['reported_hypothesis'] = extracted['log_evidence']['reported_hypothesis']
        result['extraction_issues'] = extracted['issues']
        result['evidence_status'] = 'accounted_pending_explicit_supervision_gap_review'
        require(result['audit_exit_code']==0,'Independent audit did not pass')
    except BaseException as error:
        result['evidence_status']='unresolved'
        result['error']=type(error).__name__+': '+str(error)
    write('result.json',result)
    heartbeat({'observed_utc':utc(),'status':'terminal','result_path':str(OUT/'result.json'),
        'reported_hypothesis':result.get('reported_hypothesis'),'benchmark_result':'not_assigned'})
    print(json.dumps(result,indent=2),flush=True)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check',action='store_true')
    args=parser.parse_args()
    helper,rec,plan,original,prefix,fd,record=attach()
    if args.check:
        os.close(fd)
        print(json.dumps({'status':'attach_preflight_passed','manager':MANAGER,'cpus':'14-19','old_collector_absent':True}),flush=True)
        return 0
    write('attachment.json',record)
    poller=select.poll()
    poller.register(fd,select.POLLIN)
    anomalies=[]
    known={}
    try:
        while True:
            done=bool(poller.poll(0))
            live=[]
            for entry in helper.group(MANAGER):
                if entry['state'] in ('Z','X'):
                    continue
                try:
                    p=helper.identity(entry['pid'])
                    key=(p['pid'],p['start_ticks'])
                    if key not in known:
                        expected_hash=plan['pinned_sha256'].get(p['exe'])
                        require(expected_hash and p['cwd']==str(WORK),'Unrecognized process in recorded session')
                        require(sha(Path('/proc')/str(p['pid'])/'exe')==expected_hash,'Actual session executable changed')
                        known[key]=p
                    live.append(p['pid'])
                    if not set(p['affinity'])<=CPUS:
                        item='Reserved CPU allocation violated by PID '+str(p['pid'])
                        if item not in anomalies:
                            anomalies.append(item)
                except (FileNotFoundError,ProcessLookupError):
                    # A normal engine exit can occur between identity and executable read.
                    continue
            with (WORK/'engines/sprt.pgn').open('rb') as f:
                require(f.read(len(prefix))==prefix,'PGN prefix changed while observing')
            raw=(RESUME/'resume-raw.log').read_bytes()
            completed=[int(x) for x in re.findall(rb'^Finished game (\d+) ',raw,re.M)]
            require(len(completed)==len(set(completed)) and all(i>=19 for i in completed),'Duplicate/prior completed ID in resumed raw log')
            heartbeat({'observed_utc':utc(),'status':'running' if not done else 'waiting_for_descendants',
                'observer_pid':os.getpid(),'manager_pid':MANAGER,'manager_pidfd_terminal':done,
                'live_session_pids':live,'raw_log_bytes':len(raw),'completed_games_including_original18':18+len(completed),
                'completed_count_scope':'Includes completed unpaired games; not an SPRT result',
                'anomalies':anomalies})
            if done and not live:
                ended=utc()
                write('termination-observation.json',{'observed_utc':ended,'manager_pidfd_terminal':True,
                    'live_session_pids':[],'manager_exit_code':None,'signals_sent_by_observer':[],
                    'known_processes':list(known.values()),'benchmark_result':'not_assigned'})
                terminal(helper,rec,plan,original,prefix,ended,anomalies,record['observer_sha256'])
                return 0
            poller.poll(30000) if not done else time.sleep(1)
    finally:
        os.close(fd)

if __name__=='__main__':
    try:
        raise SystemExit(main())
    except Exception as error:
        if OUT.exists() and not (OUT/'observer-error.json').exists():
            write('observer-error.json',{'observed_utc':utc(),'error':type(error).__name__+': '+str(error),
                'engine_action':'none','benchmark_result':'not_assigned'})
        raise
