#!/usr/bin/env python3
"""Start one detached observer; never start or signal chess engines."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

OUT=Path('/mnt/c/Users/Lupe/CLionProjects/ChessSI-astra/engines/rfp-removal-worktree/engines/rfp-removal-watch-01')
if os.sched_getaffinity(0)!={19}:
    raise RuntimeError('Launcher must run on CPU19')
for name in ('attachment.json','heartbeat.json','launch.json','observer.log'):
    if (OUT/name).exists():
        raise RuntimeError('Observer evidence already exists: '+name)
with (OUT/'observer.log').open('xb') as log:
    child=subprocess.Popen([sys.executable,'-B',str(OUT/'watch.py')],cwd=OUT.parent.parent,
        stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,close_fds=True,start_new_session=True)
    record={'observer_pid':child.pid,'launcher_pid':os.getpid(),'observer_detached':True,
        'stdin':'/dev/null','stdout_stderr':str(OUT/'observer.log'),'affinity':sorted(os.sched_getaffinity(child.pid)),
        'command':[sys.executable,'-B',str(OUT/'watch.py')]}
    with (OUT/'launch.json').open('x') as f:
        json.dump(record,f,indent=2)
    for _ in range(100):
        if child.poll() is not None:
            raise RuntimeError('Observer exited: '+(OUT/'observer.log').read_text())
        if (OUT/'attachment.json').exists() and (OUT/'heartbeat.json').exists():
            print(json.dumps(record),flush=True)
            break
        time.sleep(.1)
    else:
        raise RuntimeError('Observer still starting; inspect PID before any further launch')
