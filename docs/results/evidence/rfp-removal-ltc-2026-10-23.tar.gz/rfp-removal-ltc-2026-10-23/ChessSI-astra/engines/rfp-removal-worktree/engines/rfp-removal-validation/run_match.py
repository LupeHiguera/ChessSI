#!/usr/bin/env python3
"""One fresh RFP-removal comparison; natural SPRT/cap stop, immutable evidence, no acceptance."""
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import select
import signal
import subprocess
import sys
import time

ROOT = Path('/mnt/c/Users/Lupe/CLionProjects/ChessSI-astra')
WORK = ROOT / 'engines/rfp-removal-worktree'
OUT = WORK / 'engines/rfp-removal-validation'
MANAGER = Path('/home/lupe/.local/bin/fastchess')
BOOK = ROOT.parent / 'ChessSI/books/UHO_Lichess_4852_v1.epd'
MANAGER_SHA = '3d0a8f3c8b837a96366ac838f3ddf6fe87b813abb4ad2852284c0ce409132566'
BOOK_SHA = '7a7f6470615a69c6cf23d565417701d38732876f480af90d67b42abade35644a'
HELPERS = ['scripts/research/snapshot_run.py', 'scripts/research/extract_result.py',
           'scripts/research/prepare_corpus.py', 'engines/qsearch-validation/audit_match.py']
CPUS = set(range(14, 20))

def require(value, message):
    if not value:
        raise RuntimeError(message)

def utc():
    return dt.datetime.now(dt.timezone.utc)

def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            value.update(block)
    return value.hexdigest()

def safe(path):
    require(path.is_absolute() and path.is_relative_to(ROOT) and path.resolve() == path,
            'Unsafe/redirected path: ' + str(path))
    require(not any(p.is_symlink() for p in (path, *path.parents)), 'Symlink: ' + str(path))
    return path

def write(path, value):
    safe(path)
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

def identity(pid):
    path = Path('/proc') / str(pid)
    fields = (path / 'stat').read_text().rsplit(')', 1)[1].split()
    return {'pid': pid, 'start_ticks': fields[19], 'state': fields[0],
            'ppid': int(fields[1]), 'pgid': int(fields[2]), 'sid': int(fields[3]),
            'cwd': os.readlink(path / 'cwd'), 'exe': os.readlink(path / 'exe'),
            'argv': (path / 'cmdline').read_bytes().decode().split('\0')[:-1],
            'affinity': sorted(os.sched_getaffinity(pid))}

def group(pgid):
    found = []
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():
            continue
        try:
            fields = (path / 'stat').read_text().rsplit(')', 1)[1].split()
            if int(fields[2]) == pgid or int(fields[3]) == pgid:
                found.append({'pid': int(path.name), 'state': fields[0]})
        except (FileNotFoundError, ProcessLookupError):
            pass
    return found

def main():
    require(sys.flags.optimize == 0 and os.sched_getaffinity(0) == {19}, 'Use python3 -B on CPU19; no optimization')
    safe(WORK); safe(OUT)
    validation_path, main_path = OUT / 'rootvalidation.json', OUT / 'fresh-main-observation.json'
    validation = json.loads(safe(validation_path).read_text())
    require(validation['branch'] == 'astra/rfp-removal-ltc', 'Unexpected experiment branch')
    expected_names = {'Makefile', 'tests/perft.epd', 'tests/rfp.cpp'} | {
        str(p.relative_to(WORK)) for p in (WORK / 'src').iterdir() if p.suffix in ('.h', '.cpp')}
    require(len(expected_names) == 21 and set(validation['source_files_sha256']) == expected_names, 'Expected exactly21 engine/build/test inputs')
    for relative in ('config.json', 'engines/new', 'engines/base', 'engines/base-src', 'engines/sprt.pgn'):
        path = safe(WORK / relative)
        require(not path.exists(), 'Run output already exists: ' + relative)
    names = ('launch-plan.json', 'runner-identity.json', 'startup.json', 'initial-snapshot', 'initial-capture.log',
             'sprt-ltc.log', 'runner-exit.json', 'terminal-snapshot', 'terminal-capture.log',
             'terminal-state.json', 'terminal-extraction.json', 'terminal-audit', 'terminal-audit.log', 'result.json')
    for name in names:
        require(not safe(OUT / name).exists(), 'Evidence output already exists: ' + name)
    forbidden = ('SPRT_PINNED', 'GNUMAKEFLAGS', 'MAKEFILES', 'MAKEOVERRIDES', 'MFLAGS', 'CXXFLAGS',
                 'ARCH', 'LDFLAGS', 'EXE', 'OS', 'BASH_ENV', 'ENV')
    require(not any(os.environ.get(k) for k in forbidden), 'Inherited build/shell override: ' + ','.join(k for k in forbidden if os.environ.get(k)))
    env = {k: os.environ[k] for k in ('HOME', 'USER', 'LOGNAME', 'TMPDIR') if k in os.environ}
    env.update(PATH='/usr/local/bin:/usr/bin:/bin', LANG='C.UTF-8', LC_ALL='C.UTF-8',
        GIT_DIR='/mnt/c/Users/Lupe/CLionProjects/ChessSI/.git/worktrees/rfp-removal-worktree',
        GIT_WORK_TREE=str(WORK), GIT_OPTIONAL_LOCKS='0', CPUS='14-19', CONCURRENCY='5',
        MAKEFLAGS='-j6 -B', CXX='taskset -c 19 g++', BOOK=str(BOOK), FASTCHESS=str(MANAGER),
        TC='60+0.6', ELO0='-5', ELO1='0', ALPHA='0.05', BETA='0.05', ROUNDS='100000',
        PYTHONPATH=str(ROOT / 'engines/dependencies/python-chess'))
    def git(*args):
        return subprocess.check_output(['git', *args], cwd=WORK, env=env, text=True).strip()
    validation_sha = sha(validation_path)
    helpers = {name: sha(ROOT / name) for name in HELPERS}
    runner_sha = sha(WORK / 'scripts/sprt.sh')
    collector_sha = sha(Path(__file__))
    def unchanged():
        require(sha(validation_path) == validation_sha, 'Validation record changed')
        require(sha(Path(__file__)) == collector_sha, 'Collector changed')
        require(git('rev-parse', 'HEAD') == validation['head'] and git('branch', '--show-current') == validation['branch'], 'HEAD/branch changed')
        for name, digest in validation['source_files_sha256'].items():
            require(sha(safe(WORK / name)) == digest, 'Source changed: ' + name)
        for name, digest in helpers.items():
            require(sha(ROOT / name) == digest, 'Helper changed: ' + name)
        require(sha(WORK / 'scripts/sprt.sh') == runner_sha, 'SPRT script changed')
        for role in ('candidate', 'baseline'):
            require(sha(safe(OUT / (role + '-validated'))) == validation[role + '_binary_sha256'], 'Validated binary changed: ' + role)
    def main_observation():
        raw = safe(main_path).read_bytes()
        record = json.loads(raw)
        when = dt.datetime.fromisoformat(record['observed_utc'])
        require(when.tzinfo is not None and 0 <= (utc() - when).total_seconds() <= 300, 'Main observation is stale/future')
        require(record['sha'] == validation['baseline'], 'Accepted main differs')
        return record, hashlib.sha256(raw).hexdigest()
    unchanged(); observation, main_sha = main_observation()
    require(subprocess.run(['git', 'merge-base', '--is-ancestor', validation['baseline'], 'HEAD'], cwd=WORK, env=env).returncode == 0, 'Baseline is not an ancestor')
    require(sha(MANAGER) == MANAGER_SHA and sha(BOOK) == BOOK_SHA, 'Shared manager/book identity differs')
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():
            continue
        try:
            current = identity(int(path.name))
            require(not (current['cwd'] == str(WORK) and (current['exe'] == str(MANAGER) or current['exe'] in (str(WORK / 'engines/new'), str(WORK / 'engines/base')))), 'Existing own match process')
        except (FileNotFoundError, PermissionError, ProcessLookupError):
            pass
    argv = ['taskset', '-c', '14-19', 'bash', 'scripts/sprt.sh', validation['baseline']]
    plan = dict(validation, created_utc=utc().isoformat(), rootvalidation_sha256=validation_sha,
        fresh_main_observation=observation, fresh_main_observation_sha256=main_sha,
        helper_sha256=helpers, sprt_runner_sha256=runner_sha, manager_sha256=MANAGER_SHA,
        book_sha256=BOOK_SHA, environment={k: env[k] for k in ('CPUS','CONCURRENCY','MAKEFLAGS','CXX','BOOK','FASTCHESS','TC','ELO0','ELO1','ALPHA','BETA','ROUNDS')},
        argv=argv, boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
        collector_sha256=sha(Path(__file__)), stopping='Natural SPRT decision or declared200000-game cap; no wall deadline', benchmark_result='not_assigned')
    write(OUT / 'launch-plan.json', plan)
    unchanged(); require(main_observation()[1] == main_sha, 'Main observation changed before launch')
    tools = []
    def run_tool(name, args, output):
        command = ['taskset', '-c', '19', sys.executable, '-B', *map(str, args)]
        started = utc().isoformat()
        with (OUT / output).open('x', encoding='utf-8') as stream:
            completed = subprocess.run(command, cwd=WORK, env=env, stdout=stream, stderr=subprocess.STDOUT, check=False)
        record = {'name': name, 'argv': command, 'started_utc': started, 'ended_utc': utc().isoformat(),
                  'returncode': completed.returncode, 'output': str(OUT / output), 'output_sha256': sha(OUT / output)}
        tools.append(record)
        return completed.returncode
    def capture(name, manager_pids=()):
        args = [ROOT / HELPERS[0], 'capture', '--source-root', WORK, '--run-dir', WORK, '--output', OUT / name,
            '--config', WORK / 'config.json', '--log', OUT / 'sprt-ltc.log', '--pgn', WORK / 'engines/sprt.pgn',
            '--binary', 'candidate=' + str(WORK / 'engines/new'), '--binary', 'baseline=' + str(WORK / 'engines/base'),
            '--baseline', validation['baseline'], '--label', 'RFP removal fresh60+0.6 normalized[-5,0]', '--read-limit-mib', '256', '--copy-limit-mib', '128']
        for source in sorted(expected_names):
            args += ['--source-file', source]
        for pid in manager_pids:
            args += ['--pid', str(pid)]
        return run_tool(name, args, 'initial-capture.log' if manager_pids else 'terminal-capture.log')
    expected_manager_argv = [str(MANAGER), '-engine', 'cmd=engines/new', 'name=new',
        '-engine', 'cmd=engines/base', 'name=base', '-each', 'tc=60+0.6', 'option.Hash=16', 'option.Threads=1',
        '-openings', 'file=' + str(BOOK), 'format=epd', 'order=random', '-rounds', '100000', '-games', '2',
        '-repeat', '-recover', '-resign', 'movecount=3', 'score=400', 'twosided=true', '-draw',
        'movenumber=40', 'movecount=8', 'score=10', '-concurrency', '5', '-sprt', 'elo0=-5',
        'elo1=0', 'alpha=0.05', 'beta=0.05', '-pgnout', 'file=engines/sprt.pgn']
    errors, sent, manager, startup, initial = [], [], None, None, False
    with (OUT / 'sprt-ltc.log').open('x', encoding='utf-8') as log:
        child = subprocess.Popen(argv, cwd=WORK, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        leader = identity(child.pid)
        write(OUT / 'runner-identity.json', {'runner': leader, 'launch_plan_sha256': sha(OUT / 'launch-plan.json'), 'boot_id': plan['boot_id']})
        pidfd = os.pidfd_open(child.pid, 0)
        poller = select.poll(); poller.register(pidfd, select.POLLIN)
        try:
            while not poller.poll(250):
                if startup is None:
                    members = []
                    for entry in group(child.pid):
                        if entry['state'] not in ('Z', 'X'):
                            try: members.append(identity(entry['pid']))
                            except (FileNotFoundError, ProcessLookupError): pass
                    managers = [p for p in members if p['exe'] == str(MANAGER)]
                    engines = [p for p in members if p['exe'] in (str(WORK / 'engines/new'), str(WORK / 'engines/base'))]
                    require(len(managers) <= 1, 'Multiple own managers')
                    if managers:
                        manager = managers[0]
                        require(manager['argv'] == expected_manager_argv, 'Manager protocol arguments differ')
                        require(manager['cwd'] == str(WORK) and set(manager['affinity']) == CPUS and sha(Path('/proc') / str(manager['pid']) / 'exe') == MANAGER_SHA, 'Manager identity/affinity differs')
                        for role, filename in (('candidate','new'), ('baseline','base')):
                            require(sha(WORK / 'engines' / filename) == validation[role + '_binary_sha256'], 'Built binary differs: ' + role)
                        unchanged()
                        text = (OUT / 'sprt-ltc.log').read_text()
                        require(re.search(r'^new .*: bench ' + str(validation['candidate_bench']) + r'$', text, re.M) and re.search(r'^base .*: bench ' + str(validation['baseline_bench']) + r'$', text, re.M), 'Runner bench signature differs')
                        if {p['exe'] for p in engines} == {str(WORK / 'engines/new'), str(WORK / 'engines/base')}:
                            for engine in engines:
                                role = 'candidate' if engine['exe'].endswith('/new') else 'baseline'
                                require(set(engine['affinity']) == CPUS and sha(Path('/proc') / str(engine['pid']) / 'exe') == validation[role + '_binary_sha256'], 'Actual engine differs')
                            startup = {'observed_utc': utc().isoformat(), 'manager': manager, 'engines': engines, 'launch_plan_sha256': sha(OUT / 'launch-plan.json')}
                            write(OUT / 'startup.json', startup)
                            print(json.dumps({'status': 'startup_verified', 'manager': manager['pid']}), flush=True)
                if startup is not None and not initial and (WORK / 'config.json').is_file():
                    try: json.loads((WORK / 'config.json').read_text())
                    except (ValueError, OSError): continue
                    require(capture('initial-snapshot', [manager['pid']]) == 0, 'Initial snapshot failed')
                    observed = json.loads((OUT / 'initial-snapshot/manifest.json').read_text())['protocol_observed']
                    require(observed['seed_decimal'] and observed['sprt']['elo0'] == -5 and observed['sprt']['elo1'] == 0 and observed['concurrency'] == 5, 'Initial protocol/seed differs')
                    initial = True
                    print(json.dumps({'status': 'initial_snapshot', 'seed_decimal': observed['seed_decimal']}), flush=True)
        except BaseException as error:
            errors.append(type(error).__name__ + ': ' + str(error))
        finally:
            # Keep the session leader unreaped until descendants are gone, preventing PGID reuse.
            if errors and not poller.poll(0):
                os.killpg(child.pid, signal.SIGINT); sent.append('SIGINT')
                poller.poll(30000)
            remaining = [p for p in group(child.pid) if p['pid'] != child.pid and p['state'] not in ('Z', 'X')]
            if remaining or not poller.poll(0):
                errors.append('Own session required cleanup')
                for sig in (signal.SIGTERM, signal.SIGKILL):
                    try: os.killpg(child.pid, sig); sent.append(signal.Signals(sig).name)
                    except ProcessLookupError: pass
                    until = time.monotonic() + 5
                    while time.monotonic() < until:
                        remaining = [p for p in group(child.pid) if p['pid'] != child.pid and p['state'] not in ('Z','X')]
                        if not remaining and poller.poll(0): break
                        time.sleep(0.1)
                    if not remaining and poller.poll(0): break
            terminal = bool(poller.poll(0)) and not remaining
            code = child.wait() if terminal else None
            os.close(pidfd)
    ended = utc().isoformat()
    write(OUT / 'runner-exit.json', {'ended_utc': ended, 'runner_exit_code': code, 'process_terminal': terminal,
        'remaining_own_processes': remaining, 'signals_sent': sent, 'errors': errors, 'launch_plan_sha256': sha(OUT / 'launch-plan.json')})
    if not terminal:
        write(OUT / 'result.json', {'errors': errors, 'process_terminal': False, 'benchmark_result': 'not_assigned'})
        return 2
    if not startup or not initial: errors.append('Initial process/config snapshot incomplete')
    try: unchanged()
    except Exception as error: errors.append(str(error))
    final_hashes = {role: sha(WORK / 'engines' / filename) if (WORK / 'engines' / filename).is_file() else None
                    for role, filename in (('candidate','new'),('baseline','base'))}
    drift = any(final_hashes[role] != validation[role + '_binary_sha256'] for role in final_hashes)
    capture_rc = capture('terminal-snapshot')
    state = {'status': 'archived' if capture_rc == 0 else 'archive_failed', 'process_terminal': True,
        'manager': manager, 'observed_end_utc': ended, 'signal_sent': bool(sent) if code == 0 or sent else None,
        'binary_drift': drift, 'final_binary_hashes': final_hashes, 'archive': str(OUT / 'terminal-snapshot'),
        'runner_exit_code': code, 'launch_plan_sha256': sha(OUT / 'launch-plan.json'), 'benchmark_result': 'not_assigned'}
    write(OUT / 'terminal-state.json', state)
    extraction_rc = run_tool('extract', [ROOT / HELPERS[1], '--snapshot', OUT / 'terminal-snapshot', '--terminal-state', OUT / 'terminal-state.json'], 'terminal-extraction.json')
    audit_rc = run_tool('audit', [ROOT / HELPERS[3], '--snapshot', OUT / 'terminal-snapshot', '--output', OUT / 'terminal-audit'], 'terminal-audit.log')
    audit_path = OUT / 'terminal-audit/result.json'
    outcome = {'created_utc': utc().isoformat(), 'runner_exit_code': code, 'initial_snapshot_completed': initial,
        'capture_exit_code': capture_rc, 'extraction_exit_code': extraction_rc, 'audit_exit_code': audit_rc,
        'audit_result_sha256': sha(audit_path) if audit_path.is_file() else None, 'audit_result_validated': False,
        'terminal_state_sha256': sha(OUT / 'terminal-state.json'), 'tools': tools, 'errors': errors,
        'source_inputs_sha256': validation['source_files_sha256'], 'helper_sha256': helpers,
        'launch_plan_sha256': sha(OUT / 'launch-plan.json'), 'collector_sha256': sha(Path(__file__)), 'benchmark_result': 'not_assigned'}
    try:
        extracted = json.loads((OUT / 'terminal-extraction.json').read_text())
        audit = json.loads(audit_path.read_text())
        require(audit_rc == 0 and audit['snapshot_manifest_sha256'] == extracted['manifest_sha256'] and
            audit['audited_artifact_sha256'] == {name: extracted['artifact_sha256'][name] for name in ('log','pgn','config')} and
            audit['input_bindings_rechecked'] is True, 'Independent audit incomplete or bound to different inputs')
        outcome['audit_result_validated'] = True
    except (OSError, ValueError, KeyError, TypeError, RuntimeError) as error:
        errors.append('Audit result: ' + str(error))
    try:
        unchanged()
        if initial:
            def archived_config(folder):
                manifest = json.loads((folder / 'manifest.json').read_text())
                entries = [item for item in manifest['artifacts'] if item['role'] == 'config']
                require(len(entries) == 1 and entries[0]['archive_path'], 'Missing archived configuration')
                config = json.loads((folder / entries[0]['archive_path']).read_text())
                return {k: v for k, v in config.items() if k != 'stats'}
            require(archived_config(OUT / 'initial-snapshot') == archived_config(OUT / 'terminal-snapshot'), 'Initial/terminal protocol or seed differs')
    except Exception as error: errors.append(str(error))
    outcome['collector_exit_code'] = 0 if code == capture_rc == extraction_rc == audit_rc == 0 and not errors and not drift else 2
    write(OUT / 'result.json', outcome)
    print(json.dumps(outcome, indent=2), flush=True)
    return outcome['collector_exit_code']

if __name__ == '__main__':
    raise SystemExit(main())