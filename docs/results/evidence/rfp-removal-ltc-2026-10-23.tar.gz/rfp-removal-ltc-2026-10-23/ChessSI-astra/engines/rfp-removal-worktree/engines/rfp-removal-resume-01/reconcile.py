#!/usr/bin/env python3
"""Narrow evidence reconciliation for the interrupted 18-game RFP removal run.

Pure functions: never modify raw logs, execute tools, or assign a strength verdict.
Callers must decode raw UTF-8 bytes without newline translation and bind archives,
protocol, processes, binary identities, and the original PGN byte prefix separately.
"""
import hashlib
import re

CAP = 200000
PREFIX = set(range(1, 19))
UNFINISHED = set(range(19, 24))
HEADERS = (
    'new  (705ec08+working tree): bench 358129',
    'base (c7e27702fe361e477de2afb3b26f5dafdc6b2e8f): bench 276006',
    'SPRT [-5, 0] alpha 0.05 beta 0.05 at 60+0.6, 5 games in parallel on cores 14-19, at most 100000 pairs',
    'Indexing opening suite...',
)
INTERRUPTION = ('Tournament was interrupted. To resume the tournament, run: '
                '/home/lupe/.local/bin/fastchess -config file=config.json')
START = re.compile(r'Started game (\d+) of (\d+) \((new|base) vs (new|base)\)')
FINISH = re.compile(r'Finished game (\d+) \((new|base) vs (new|base)\): (1-0|0-1|1/2-1/2) \{(.+)\}')
TIME = re.compile(r'Total Time: \d{2,}:\d{2}:\d{2} \(hours:minutes:seconds\)')
COUNTS = ('games', 'wins', 'losses', 'draws', 'pentanomial')
EXPECTED_STATS = {
    'wins': 2, 'losses': 6, 'draws': 10,
    'penta_WW': 0, 'penta_WD': 1, 'penta_WL': 1,
    'penta_DD': 3, 'penta_LD': 3, 'penta_LL': 1,
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def lines(text, label):
    require(isinstance(text, str) and text.endswith('\n'), label + ': incomplete text')
    require('\x00' not in text, label + ': NUL byte')
    records = text.splitlines(keepends=True)
    require(all(x.endswith('\n') for x in records), label + ': unsupported line separator')
    return records


def event(line, started, finished, minimum, maximum):
    """Validate one event; return ('start'/'finish', id), or None."""
    start, finish = START.fullmatch(line), FINISH.fullmatch(line)
    if start or finish:
        match = start or finish
        ident = int(match[1])
        require(minimum <= ident <= maximum, 'Game ID outside permitted segment')
        if start:
            total, white, black = int(match[2]), match[3], match[4]
            require(total == CAP, 'Changed game cap')
            require(ident not in started, 'Duplicate game start')
        else:
            white, black = match[2], match[3]
            require(ident not in finished, 'Duplicate game finish')
            require(started.get(ident) == (white, black), 'Finish without matching start')
        require((white, black) == (('new', 'base') if ident % 2 else ('base', 'new')),
                'Unexpected game colors')
        if start:
            started[ident] = (white, black)
            require(len(started) - len(finished) <= 5, 'More than five active games')
            return 'start', ident
        half = {'1-0': 2, '0-1': 0, '1/2-1/2': 1}[match[4]]
        finished[ident] = {'id': ident, 'round': (ident + 1) // 2, 'white': white,
                          'half_points': half if white == 'new' else 2-half}
        return 'finish', ident
    require(not line.startswith(('Started game ', 'Finished game ')), 'Malformed game event')
    return None


def validate_six_counters(config_stats, pgn_games):
    """Compare raw config W/L/D and all SIX penta bins with auditor PGN rows."""
    rows, pairs = {}, {}
    for row in pgn_games:
        ident, number, half = row['id'], row['round'], row['half_points']
        require(type(ident) is int and ident > 0 and ident not in rows, 'Invalid/duplicate PGN ID')
        require(type(number) is int and number == (ident + 1) // 2, 'Invalid PGN round')
        require(row['white'] == ('new' if ident % 2 else 'base'), 'Invalid PGN pair color')
        require(type(half) is int and half in (0, 1, 2), 'Invalid PGN score')
        rows[ident] = row
        pairs.setdefault(number, []).append(row)
    counts = {key: 0 for key in EXPECTED_STATS}
    counted, unpaired = [], []
    for group in pairs.values():
        require(len(group) <= 2, 'Too many PGN games in pair')
        if len(group) == 1:
            unpaired.append(group[0]['id'])
            continue
        a, b = (row['half_points'] for row in group)
        suffix = {0: 'LL', 1: 'LD', 3: 'WD', 4: 'WW'}.get(a+b)
        if suffix is None:
            suffix = 'DD' if a == b == 1 else 'WL'
        counts['penta_' + suffix] += 1
        for row in group:
            counts[{2: 'wins', 0: 'losses', 1: 'draws'}[row['half_points']]] += 1
            counted.append(row['id'])
    require(all(type(config_stats.get(k)) is int and config_stats[k] >= 0 for k in counts),
            'Missing or invalid config counter')
    require(all(config_stats[k] == v for k, v in counts.items()), 'Six-counter PGN/config mismatch')
    return {'validated_stats': counts, 'counted_game_ids': sorted(counted),
            'unpaired_game_ids': sorted(unpaired)}


def reconcile(old_text, new_text):
    """Return an explicitly derived logical log and lossless omission provenance."""
    old, new = lines(old_text, 'Original log'), lines(new_text, 'Resumed log')
    require(tuple(x.rstrip('\r\n') for x in old[:4]) == HEADERS, 'Unexpected original headers')
    started, finished, kept, omitted = {}, {}, old[:4], []
    footer = 0
    for line_no, raw in enumerate(old[4:], 5):
        line = raw.rstrip('\r\n')
        reason = None
        if footer:
            if footer == 1:
                require(line == 'Finished match', 'Expected original final marker')
                reason, footer = 'original_final_marker', 2
            elif footer == 2:
                require(TIME.fullmatch(line), 'Expected original time footer')
                reason, footer = 'original_time_footer', 3
            else:
                require(not line, 'Unexpected original event after terminal footer')
        elif line == INTERRUPTION:
            reason, footer = 'original_interruption', 1
        else:
            found = event(line, started, finished, 1, 23)
            require(found is not None, 'Unexpected original content (including statistics/decision)')
            if found[0] == 'start' and found[1] in UNFINISHED:
                reason = 'original_unfinished_start'
        if reason:
            omitted.append({'line_number': line_no, 'text': raw, 'reason': reason})
        else:
            kept.append(raw)
    require(footer == 3, 'Incomplete original terminal footer')
    require(set(started) == PREFIX | UNFINISHED and set(finished) == PREFIX,
            'Original completed IDs must be exactly 1-18 and unfinished IDs 19-23')
    validate_six_counters(EXPECTED_STATS, list(finished.values()))
    new_started, new_finished, terminal, time_footer = {}, {}, False, False
    for raw in new:
        line = raw.rstrip('\r\n')
        if terminal:
            if not line:
                continue
            require(not time_footer and TIME.fullmatch(line), 'Unexpected event after resumed final marker')
            time_footer = True
            continue
        if line == 'Finished match':
            terminal = True
            continue
        require(not TIME.fullmatch(line), 'Resumed time footer precedes final marker')
        event(line, new_started, new_finished, 19, CAP)
    require(terminal, 'Resumed log lacks final marker')
    require(new_started and set(new_started) == set(range(19, max(new_started)+1)),
            'Resumed starts must form a contiguous sequence beginning at 19')
    derived = ''.join(kept) + new_text
    return derived, {
        'schema_version': 1, 'kind': 'derived_log_from_two_raw_sessions',
        'old_sha256': digest(old_text), 'new_sha256': digest(new_text),
        'derived_sha256': digest(derived), 'encoding': 'UTF-8; no newline normalization',
        'old_bytes': len(old_text.encode('utf-8')), 'new_bytes': len(new_text.encode('utf-8')),
        'derived_bytes': len(derived.encode('utf-8')),
        'old_completed_game_ids': sorted(finished),
        'old_unfinished_game_ids': sorted(UNFINISHED),
        'new_started_game_ids': sorted(new_started), 'new_finished_game_ids': sorted(new_finished),
        'omitted_old_lines': omitted, 'new_text_preserved_verbatim': True,
        'scope': 'Accounting projection, not a physical single-session log or a benchmark verdict.',
        'benchmark_result': 'not_assigned',
    }


def validate_final(audit_result, log_evidence):
    """Require complete cumulative accounting; decision/identity gates remain caller-owned."""
    pgn, log = audit_result['pgn_pair_aggregate'], audit_result['log_pair_aggregate']
    config, extracted = audit_result['config_counts'], log_evidence['final_paired_counts']
    require(all({k: obj[k] for k in COUNTS} == {k: config[k] for k in COUNTS}
                for obj in (pgn, log, extracted)), 'Final config/PGN/log totals disagree')
    ids, unpaired = pgn['counted_game_ids'], pgn['unpaired_game_ids']
    require(ids == sorted(set(ids)) and len(ids) == config['games'] and PREFIX <= set(ids),
            'Invalid final counted IDs')
    require(unpaired == sorted(set(unpaired)) and not set(ids) & set(unpaired),
            'Invalid final unpaired IDs')
    require(log['counted_game_ids'] == ids and log['unpaired_game_ids'] == unpaired and
            log_evidence['unpaired_completed_game_ids'] == unpaired, 'Final game IDs disagree')
    require(all(not audit_result[k] for k in ('log_report_count_mismatches', 'log_games_not_in_pgn_snapshot',
            'pgn_games_not_in_log_snapshot', 'suspect_termination_reasons')), 'Unresolved audit gaps or issues')
    total = len(ids) + len(unpaired)
    require(all(audit_result[k] == total for k in ('pgn_games_legally_replayed', 'log_finished_games',
            'cross_source_game_results_compared')) and log_evidence['completed_log_games'] == total,
            'Incomplete final game coverage')
    return {'accounting_complete': True, 'counts': {k: config[k] for k in COUNTS},
            'counted_game_ids': ids, 'unpaired_game_ids': unpaired, 'benchmark_result': 'not_assigned'}
