import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT=Path('/mnt/c/Users/Lupe/CLionProjects/ChessSI-astra/engines/rfp-removal-worktree')
OUT=ROOT/'engines/rfp-removal-validation'
BASE='c7e27702fe361e477de2afb3b26f5dafdc6b2e8f'
env=dict(os.environ,GIT_DIR='/mnt/c/Users/Lupe/CLionProjects/ChessSI/.git/worktrees/rfp-removal-worktree',GIT_WORK_TREE=str(ROOT))
def git(*args): return subprocess.check_output(['git',*args],env=env,cwd=ROOT)
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not git('diff','afe9aab6002ccf7e878d5622f86870383e301fb3',BASE,'--','src','Makefile','tests','scripts/sprt.sh')
assert not git('diff','36bef70','HEAD','--','src','Makefile','tests','scripts/sprt.sh')
previous=json.loads((OUT/'validation.json').read_text())
assert previous['sanitizer_passed']
for path,digest in previous['sha256'].items(): assert sha(OUT/path)==digest,path
inputs=['Makefile','tests/rfp.cpp','tests/perft.epd']+[str(p.relative_to(ROOT)) for p in sorted((ROOT/'src').iterdir()) if p.suffix in ('.cpp','.h')]
assert len(inputs)==21
source_hashes={p:sha(ROOT/p) for p in inputs}
for p,digest in source_hashes.items():
    assert hashlib.sha256(git('show','HEAD:'+p)).hexdigest()==digest,p
record={'recorded_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'baseline':BASE,
        'head':git('rev-parse','HEAD').decode().strip(),'branch':git('branch','--show-current').decode().strip(),
        'candidate_bench':358129,'baseline_bench':276006,'source_files_sha256':source_hashes,
        'candidate_binary_sha256':sha(OUT/'candidate-validated'),'baseline_binary_sha256':sha(OUT/'baseline-validated'),
        'validation_record_sha256':sha(OUT/'validation.json'),
        'baseline_equivalence':'Only AGENTS.md and docs/IDEAS.md changed from afe9aab to c7e2770; validated engine/build/test inputs are unchanged.',
        'candidate_equivalence':'After rebase, engine/build/test inputs are identical to tested candidate 36bef70.',
        'validation_summary':'35 perft and 17 boundary cases pass for baseline and candidate; 17 candidate boundary cases pass under ASan/UBSan.',
        'collector_sha256':sha(__file__)}
with (OUT/'rootvalidation.json').open('x') as f: json.dump(record,f,indent=2);f.write('\n')
print(json.dumps({k:record[k] for k in ('baseline','head','branch','candidate_bench','baseline_bench','candidate_binary_sha256','baseline_binary_sha256')},indent=2))
