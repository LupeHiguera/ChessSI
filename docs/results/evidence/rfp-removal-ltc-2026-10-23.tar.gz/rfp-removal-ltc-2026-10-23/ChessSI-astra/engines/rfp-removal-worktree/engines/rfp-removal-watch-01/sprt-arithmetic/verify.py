#!/usr/bin/env python3
"""Validate pinned SPRT arithmetic and apply it to audited, complete-pair reports."""
import argparse
import datetime as dt
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess

HERE=Path(__file__).resolve().parent
BINARY=HERE/'sprt-evaluate'
KEYS=('penta_LL','penta_LD','penta_WL','penta_DD','penta_WD','penta_WW')
def require(ok,why):
    if not ok: raise ValueError(str(why))
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def counts(rows):
    byid={x['id']:x for x in rows}
    require(len(byid)==len(rows),'Duplicate IDs')
    bins=[0]*6
    for ident,row in sorted(byid.items()):
        if ident%2==0: continue
        require(ident+1 in byid,'Unpaired selection')
        a,b=row['half_points'],byid[ident+1]['half_points']
        require(a in (0,1,2) and b in (0,1,2),'Invalid score')
        require(row['white']=='new' and byid[ident+1]['white']=='base','Invalid color')
        index={(0,0):0,(0,1):1,(1,0):1,(0,2):2,(2,0):2,(1,1):3,(1,2):4,(2,1):4,(2,2):5}[(a,b)]
        bins[index]+=1
    require(2*sum(bins)==len(rows),'Missing odd partner')
    return bins
def evaluate(c):
    run=subprocess.run([str(BINARY),*map(str,c)],capture_output=True,text=True,check=True)
    r=json.loads(run.stdout)
    require(all(math.isfinite(r[k]) for k in ('llr','lower','upper')),'Nonfinite pinned arithmetic')
    require(abs(r['upper']-math.log(19))<1e-14 and abs(r['lower']+math.log(19))<1e-14,'Unexpected bounds')
    return r
def independent(c):
    merged=[c[0],c[1],c[2]+c[3],c[4],c[5]]
    adjusted=[float(x) if x else .001 for x in merged]
    n=sum(adjusted); q=[x/n for x in adjusted]
    scores=[0.,.25,.5,.75,1.]
    def fit(t):
        p=[.2]*5
        for _ in range(10):
            mu=sum(a*b for a,b in zip(scores,p))
            variance=sum(b*(a-mu)**2 for a,b in zip(scores,p))
            sd=math.sqrt(variance)
            phi=[a-.5-.5*t*sd*(1+((a-mu)/sd)**2) for a in scores]
            lo,hi=-1/max(phi),-1/min(phi)
            for _ in range(100):
                mid=(lo+hi)/2
                if mid==lo or mid==hi: break
                f=sum(v*x/(1+mid*x) for v,x in zip(q,phi))
                if f>0: lo=mid
                else: hi=mid
            theta=(lo+hi)/2
            new=[v/(1+theta*x) for v,x in zip(q,phi)]
            change=max(abs(a-b) for a,b in zip(p,new))
            p=new
            if change<1e-4: break
        return p
    p0=fit(math.sqrt(2)*-5/(800/math.log(10)))
    p1=fit(0.)
    return n*sum(v*(math.log(b)-math.log(a)) for v,a,b in zip(q,p0,p1))
def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--audit',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args()
    require(os.sched_getaffinity(0)=={19},'Use onlyCPU19')
    manifest=json.loads((HERE/'sources.json').read_bytes())
    for item in manifest['files']:
        path=HERE/Path(item['path'].replace('\\','/'))
        require(sha(path)==item['sha256'],'Arithmetic source drift')
    fixtures={
      'original18':[1,3,1,3,1,0],
      'reported60':[4,9,6,5,4,2],
      'balanced':[10,20,15,15,20,10],
      'negative':[1000,400,200,200,50,10],
      'positive':[10,50,200,200,400,1000],
      'all_draw_pairs':[0,0,0,100,0,0],
      'all_split_pairs':[0,0,100,0,0,0],
    }
    checked=[]
    for name,c in fixtures.items():
        r=evaluate(c); alt=independent(c)
        require(abs(r['llr']-alt)<1e-5,'Independent arithmetic disagrees: '+name)
        if name=='reported60':
            require(abs(r['llr']-(-.15572898927836))<1e-6,'Observed60 fixture differs')
        checked.append({'case':name,'six_counts':dict(zip(KEYS,c)),**r,
            'independent_bisection_llr':alt,'difference':r['llr']-alt})
    require(checked[-1]['llr']==checked[-2]['llr'],'WL/DD must merge before regularization')
    require(any(x['decision']=='H0' for x in checked) and any(x['decision']=='H1' for x in checked),'Fixtures fail to cover both bounds')
    for bad in ([],[0]*6,[-1,0,0,0,0,1],[100001,0,0,0,0,0]):
        require(subprocess.run([str(BINARY),*map(str,bad)],capture_output=True).returncode!=0,'Invalid input accepted')
    audit=json.loads((args.audit/'result.json').read_bytes())
    reports=json.loads((args.audit/'reports.json').read_bytes())
    games={x['id']:x for x in json.loads((args.audit/'pgn-games.json').read_bytes())}
    require(not audit['log_report_count_mismatches'],'Prior report audit failed')
    verified=[]
    for report in reports:
        ids=report['reconstructed']['counted_game_ids']
        c=counts([games[i] for i in ids])
        r=evaluate(c); expected=report['reported']
        require(all(r[k]==expected[k] for k in ('games','wins','losses','draws')),'Reconstructed sixcounts disagree with report')
        require([c[0],c[1],c[2]+c[3],c[4],c[5]]==expected['pentanomial'],'Report penta mismatch')
        alt=independent(c)
        require(abs(r['llr']-alt)<1e-5,'Report independent arithmetic mismatch')
        verified.append({'line':report['line'],'six_counts':dict(zip(KEYS,c)),
            'counted_ids':ids,**r,'independent_bisection_llr':alt})
    result={'observed_utc':dt.datetime.now(dt.timezone.utc).isoformat(),
        'source_revision':manifest['source_revision'],'sources_manifest_sha256':sha(HERE/'sources.json'),
        'evaluator_sha256':sha(BINARY),'verifier_sha256':sha(__file__),
        'compiler':subprocess.check_output(['g++','--version'],text=True).splitlines()[0],
        'compiler_flags':['-std=c++20','-O2','-fno-fast-math'],
        'audit_sha256':sha(args.audit/'result.json'),'reports_sha256':sha(args.audit/'reports.json'),
        'pgn_games_sha256':sha(args.audit/'pgn-games.json'),'fixtures':checked,
        'invalid_input_checks_passed':4,'verified_reports':verified,
        'scope':'Source-level arithmetic reproduction plus independent bisection; no installed-manager binary equivalence claim',
        'benchmark_result':'not_assigned'}
    with args.output.open('x') as f: json.dump(result,f,indent=2)
    print(json.dumps({'fixtures_passed':len(checked),'invalid_inputs_rejected':4,
        'reports_verified':len(verified),'reported_games':[x['games'] for x in verified],
        'llrs':[x['llr'] for x in verified],'benchmark_result':'not_assigned'}),flush=True)
if __name__=='__main__': main()
