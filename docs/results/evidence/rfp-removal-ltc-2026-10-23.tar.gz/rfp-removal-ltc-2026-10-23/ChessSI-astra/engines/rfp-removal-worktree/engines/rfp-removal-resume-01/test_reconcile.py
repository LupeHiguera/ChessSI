#!/usr/bin/env python3
"""Focused fixtures; no engines, subprocesses, files written, or replay workloads."""
import copy
import importlib.util
import os
from pathlib import Path
import sys
import unittest

if sys.flags.optimize or not __debug__ or os.sched_getaffinity(0) != {19}:
    raise RuntimeError('Run unoptimized Python only on WSL CPU 19')

import reconcile as r

ROOT = Path('/mnt/c/Users/Lupe/CLionProjects/ChessSI-astra')
sys.path.insert(0, str(ROOT / 'scripts/research'))
import extract_result

HALVES = [0, 0, 0, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 2, 0, 2, 1]
PROTOCOL = {'sprt': {'enabled': True, 'model': 'normalized', 'elo0': -5, 'elo1': 0,
                    'alpha': .05, 'beta': .05}, 'rounds': 100000, 'games_per_round': 2}


def start(ident):
    white, black = ('new', 'base') if ident % 2 else ('base', 'new')
    return f'Started game {ident} of 200000 ({white} vs {black})'


def finish(ident, half=1):
    white, black = ('new', 'base') if ident % 2 else ('base', 'new')
    white_half = half if white == 'new' else 2-half
    result = {0: '0-1', 1: '1/2-1/2', 2: '1-0'}[white_half]
    reason = {0: 'Black wins by adjudication', 1: 'Draw by adjudication',
              2: 'White wins by adjudication'}[white_half]
    return f'Finished game {ident} ({white} vs {black}): {result} {{{reason}}}'


def original():
    text = list(r.HEADERS) + [start(i) for i in range(1, 6)]
    for ident, half in enumerate(HALVES, 1):
        text.extend((finish(ident, half), start(ident+5)))
    text.extend((r.INTERRUPTION, 'Finished match',
                 'Total Time: 00:13:19 (hours:minutes:seconds)', ''))
    return '\n'.join(text) + '\n'


def resumed():
    return '\n'.join([
        'Loading config file: resume-config.json',
        'Indexing opening suite...',
        start(19), start(20), finish(19), finish(20),
        'Results of new vs base (60+0.6):',
        'Elo: -70.00 +/- 90.00, nElo: -60.00 +/- 80.00',
        'Games: 20, Wins: 2, Losses: 6, Draws: 12, Points: 8.0 (40.00 %)',
        'Ptnml(0-2): [1, 3, 5, 1, 0], WL/DD Ratio: 0.25',
        'LLR: -2.94 (-100.00%) (-2.94, 2.94) [-5.00, 0.00]',
        'SPRT ([-5.00, 0.00]) completed - H0 was accepted',
        'Finished match', 'Total Time: 00:01:00 (hours:minutes:seconds)', '',
    ])


def pgn_rows():
    return [{'id': i, 'round': (i+1)//2, 'white': 'new' if i % 2 else 'base',
             'half_points': half} for i, half in enumerate(HALVES, 1)]


def final_fixture():
    counts = {'games': 18, 'wins': 2, 'losses': 6, 'draws': 10, 'pentanomial': [1, 3, 4, 1, 0]}
    aggregate = dict(counts, counted_game_ids=list(range(1, 19)), unpaired_game_ids=[])
    audit = {'pgn_pair_aggregate': copy.deepcopy(aggregate), 'log_pair_aggregate': copy.deepcopy(aggregate),
             'config_counts': counts, 'log_report_count_mismatches': [], 'log_games_not_in_pgn_snapshot': [],
             'pgn_games_not_in_log_snapshot': [], 'suspect_termination_reasons': {},
             'pgn_games_legally_replayed': 18, 'log_finished_games': 18, 'cross_source_game_results_compared': 18}
    evidence = {'final_paired_counts': copy.deepcopy(counts), 'unpaired_completed_game_ids': [],
                'completed_log_games': 18}
    return audit, evidence


class ReconcileTests(unittest.TestCase):
    def test_derived_reconciles_cumulative_report_with_existing_extractor(self):
        derived, proof = r.reconcile(original(), resumed())
        parsed = extract_result.inspect_log(derived, PROTOCOL)
        self.assertEqual(parsed['issues'], [])
        self.assertEqual(parsed['final_paired_counts']['games'], 20)
        self.assertEqual(parsed['reported_hypothesis'], 'H0')
        self.assertEqual(len(proof['omitted_old_lines']), 8)
        self.assertEqual(proof['old_completed_game_ids'], list(range(1, 19)))
        self.assertEqual(proof['old_unfinished_game_ids'], list(range(19, 24)))
        self.assertTrue(derived.endswith(resumed()))
        for i, half in enumerate(HALVES, 1):
            self.assertEqual(derived.count(finish(i, half) + '\n'), 1)
        self.assertEqual(proof['old_sha256'], r.digest(original()))
        self.assertEqual(proof['new_sha256'], r.digest(resumed()))
        self.assertEqual(proof['derived_sha256'], r.digest(derived))
        old_lines = original().splitlines(keepends=True)
        for omitted in proof['omitted_old_lines']:
            self.assertEqual(old_lines[omitted['line_number']-1], omitted['text'])
        removed = {item['line_number'] for item in proof['omitted_old_lines']}
        retained = ''.join(raw for i, raw in enumerate(old_lines, 1) if i not in removed)
        self.assertEqual(derived, retained + resumed())

    def test_actual_frozen_original_is_compatible(self):
        path = Path(__file__).resolve().parent.parent / 'rfp-removal-validation/terminal-snapshot/files/0024-sprt-ltc.log'
        text = path.read_bytes().decode('utf-8')
        self.assertEqual(r.digest(text), '7121af4dd4e58e45a649585da5a742c0f17d863092e9699b16bbdb1abdfe6ba0')
        derived, proof = r.reconcile(text, resumed())
        self.assertEqual(extract_result.inspect_log(derived, PROTOCOL)['issues'], [])
        self.assertEqual([item['line_number'] for item in proof['omitted_old_lines']], [37, 39, 41, 43, 45, 46, 47, 48])

    def test_restarted_unfinished_ids_allowed(self):
        derived, _ = r.reconcile(original(), resumed())
        self.assertEqual(derived.count(start(19) + '\n'), 1)
        self.assertEqual(derived.count(start(20) + '\n'), 1)

    def test_missing_old_pair_rejected(self):
        text = original().replace(finish(17, HALVES[16]) + '\n', '').replace(finish(18, HALVES[17]) + '\n', '')
        with self.assertRaises(ValueError):
            r.reconcile(text, resumed())

    def test_duplicate_finish_rejected_in_either_segment(self):
        for old, new in ((original().replace(finish(1, 0), finish(1, 0) + '\n' + finish(1, 0)), resumed()),
                         (original(), resumed().replace(finish(19), finish(19) + '\n' + finish(19)))):
            with self.subTest(old_duplicate=old != original()), self.assertRaises(ValueError):
                r.reconcile(old, new)

    def test_resumed_old_id_rejected(self):
        with self.assertRaises(ValueError):
            r.reconcile(original(), start(18) + '\n' + resumed())

    def test_original_late_event_rejected(self):
        for insertion in (original() + start(24) + '\n',
                          original().replace('Finished match\n', 'Finished match\n' + finish(19) + '\n')):
            with self.assertRaises(ValueError):
                r.reconcile(insertion, resumed())

    def test_old_statistics_or_decision_never_silently_removed(self):
        for line in ('Games: 18, Wins: 2, Losses: 6, Draws: 10,', 'SPRT ([-5, 0]) completed - H0 was accepted'):
            with self.assertRaises(ValueError):
                r.reconcile(original().replace(r.INTERRUPTION, line + '\n' + r.INTERRUPTION), resumed())

    def test_duplicate_new_marker_and_post_terminal_events_rejected(self):
        for extra in ('Finished match\n', start(21) + '\n', 'Games: 20, Wins: 2, Losses: 6, Draws: 12,\n'):
            with self.assertRaises(ValueError):
                r.reconcile(original(), resumed() + extra)

    def test_missing_terminal_or_matching_start_rejected(self):
        for new in (resumed().replace('Finished match\n', ''),
                    resumed().replace(start(19) + '\n', '')):
            with self.assertRaises(ValueError):
                r.reconcile(original(), new)

    def test_changed_cap_or_colors_rejected(self):
        for new in (resumed().replace('of 200000', 'of 1000'),
                    resumed().replace(start(19), 'Started game 19 of 200000 (base vs new)')):
            with self.assertRaises(ValueError):
                r.reconcile(original(), new)

    def test_new_start_gap_and_truncated_line_rejected(self):
        for new in (start(21) + '\nFinished match\n', resumed().rstrip('\n')):
            with self.assertRaises(ValueError):
                r.reconcile(original(), new)

    def test_crlf_preserved_exactly(self):
        old, new = original().replace('\n', '\r\n'), resumed().replace('\n', '\r\n')
        derived, proof = r.reconcile(old, new)
        self.assertTrue(derived.endswith(new))
        self.assertEqual(proof['old_sha256'], r.digest(old))
        self.assertTrue(all(item['text'].endswith('\r\n') for item in proof['omitted_old_lines']))

    def test_interruption_is_retained_without_inventing_decision(self):
        new = '\n'.join((start(19), r.INTERRUPTION, 'Finished match', ''))
        derived, proof = r.reconcile(original(), new)
        self.assertIn(r.INTERRUPTION, derived)
        self.assertEqual(proof['new_finished_game_ids'], [])
        self.assertIsNone(extract_result.inspect_log(derived, PROTOCOL)['reported_hypothesis'])

    def test_six_counter_validation(self):
        result = r.validate_six_counters(r.EXPECTED_STATS, pgn_rows())
        self.assertEqual(result['validated_stats'], r.EXPECTED_STATS)
        self.assertEqual(result['unpaired_game_ids'], [])

    def test_merged_middle_bin_cannot_hide_wl_dd_mismatch(self):
        wrong = dict(r.EXPECTED_STATS, penta_WL=2, penta_DD=2)
        with self.assertRaisesRegex(ValueError, 'Six-counter'):
            r.validate_six_counters(wrong, pgn_rows())

    def test_duplicate_pgn_id_and_bad_color_rejected(self):
        for rows in (pgn_rows() + [pgn_rows()[0]], [dict(pgn_rows()[0], white='base')] + pgn_rows()[1:]):
            with self.assertRaises(ValueError):
                r.validate_six_counters(r.EXPECTED_STATS, rows)

    def test_unpaired_pgn_retained_but_not_counted(self):
        rows = pgn_rows() + [{'id': 19, 'round': 10, 'white': 'new', 'half_points': 2}]
        result = r.validate_six_counters(r.EXPECTED_STATS, rows)
        self.assertEqual(result['unpaired_game_ids'], [19])
        self.assertEqual(len(result['counted_game_ids']), 18)

    def test_final_accounting_success_is_not_acceptance(self):
        result = r.validate_final(*final_fixture())
        self.assertTrue(result['accounting_complete'])
        self.assertEqual(result['benchmark_result'], 'not_assigned')

    def test_final_counts_gaps_ids_and_coverage_fail_closed(self):
        mutations = (
            lambda a, e: a['config_counts'].update(wins=3),
            lambda a, e: a['pgn_games_not_in_log_snapshot'].append(1),
            lambda a, e: a['log_pair_aggregate']['counted_game_ids'].pop(),
            lambda a, e: a.update(cross_source_game_results_compared=17),
            lambda a, e: a['log_report_count_mismatches'].append({'line': 1}),
            lambda a, e: a['suspect_termination_reasons'].update({'White loses on time': 1}),
            lambda a, e: e['final_paired_counts'].update(games=20),
        )
        for mutation in mutations:
            audit, evidence = final_fixture()
            mutation(audit, evidence)
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                r.validate_final(audit, evidence)


if __name__ == '__main__':
    unittest.main(verbosity=2)
