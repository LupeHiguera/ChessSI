#pragma once
#define LOG_TRACE(...) ((void)0)
namespace fastchess {
class Logger {
public:
 enum class Level { WARN };
 template<Level, class... Args> static void print(const char*,Args&&...) {}
};
}
