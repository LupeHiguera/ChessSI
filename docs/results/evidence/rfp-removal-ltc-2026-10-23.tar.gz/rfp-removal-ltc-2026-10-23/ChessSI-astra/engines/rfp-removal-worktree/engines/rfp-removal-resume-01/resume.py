#!/usr/bin/env python3
"""Continue exactly the frozen eighteen-game RFP ablation; preserve both raw sessions."""
import argparse
import datetime as dt
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import select
import signal
import subprocess
import sys
import time

ROOT = Path('/mnt/c/Users/Lupe/CLionProjects/ChessSI-astra')
WORK = ROOT / 'engines/rfp-removal-worktree'
OLD = WORK / 'engines/rfp-removal-validation'
OUT = WORK / 'engines/rfp-removal-resume-01'
BASE = 'c7e27702fe361e477de2afb3b26f5dafdc6b2e8f'
PREFIX_MANIFEST = '015b529e93130b11f75b2e44433b211594e1a0e85ca911cd613427b50a83a59a'
PREFIX_AUDIT = '4f17393e629884fdc0a23b4344851ed901e576961612d5b079f177445f7fd0b3'
CPUS = set(range(14, 20))

def require(ok, message):
    if not ok:
        raise RuntimeError(str(message))

def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat()

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()

def load_module(name, path):
    source = path.read_bytes()
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    exec(compile(source, str(path), 'exec'), module.__dict__)
    return module

def write(name, value):
    path = OUT / name
    require(path.resolve() == path and path.is_relative_to(OUT), 'Unsafe output path')
    with path.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, indent=2)
        f.write('\n')

def copy_exact(source, target):
    with target.open('xb') as f:
        f.write(source.read_bytes())
    require(sha(source) == sha(target), 'Copy identity differs')

def context():
    require(os.sched_getaffinity(0) == {19} and sys.flags.optimize == 0, 'Run python3 -B only on CPU19')
    for path in (ROOT, WORK, OLD, OUT):
        require(path.resolve() == path and not any(p.is_symlink() for p in (path, *path.parents)), 'Redirected path')
    require(sha(OLD / 'launch-plan.json') == '955f62b857a9489a832047be76f8b287e7ebfae44c383b6636ecd7b0b26c47bd', 'Original launch plan changed')
    require(sha(OLD / 'run_match.py') == '1fb8b65b368b5bb48e5933ec490ca9f12e40cf555975158737b12e5e246c89c5', 'Original identity helper changed')
    old = load_module('frozen_runner', OLD / 'run_match.py')
    validation = json.loads((OLD / 'launch-plan.json').read_bytes())
    require(validation['baseline'] == BASE and validation['head'] == '705ec08bbac6565f0d7f242d0c9780821762ab73', 'Comparison changed')
    env = {k: os.environ[k] for k in ('HOME', 'USER', 'LOGNAME', 'TMPDIR') if k in os.environ}
    env.update(PATH='/usr/local/bin:/usr/bin:/bin', LANG='C.UTF-8', LC_ALL='C.UTF-8',
        GIT_DIR='/mnt/c/Users/Lupe/CLionProjects/ChessSI/.git/worktrees/rfp-removal-worktree',
        GIT_WORK_TREE=str(WORK), GIT_OPTIONAL_LOCKS='0',
        PYTHONPATH=str(ROOT / 'engines/dependencies/python-chess'))
    def git(*args):
        return subprocess.check_output(['git', *args], cwd=WORK, env=env, text=True).strip()
    require(git('rev-parse', 'HEAD') == validation['head'] and git('branch', '--show-current') == validation['branch'], 'Candidate branch/head changed')
    archive = OLD / 'terminal-snapshot'
    require(sha(archive / 'manifest.json') == PREFIX_MANIFEST, 'Original manifest changed')
    require(sha(OLD / 'terminal-audit/result.json') == PREFIX_AUDIT, 'Original audit changed')
    snap = load_module('snapshot_run', ROOT / 'scripts/research/snapshot_run.py')
    require(snap.verify_archive(archive)['integrity_ok'], 'Original archive failed verification')
    manifest = json.loads((archive / 'manifest.json').read_bytes())
    artifacts = {r['role']: archive / r['archive_path'] for r in manifest['artifacts'] if r['role'] != 'source'}
    for relative, digest in validation['source_files_sha256'].items():
        require(sha(WORK / relative) == digest, 'Engine input changed: ' + relative)
    for relative, digest in validation['helper_sha256'].items():
        require(sha(ROOT / relative) == digest, 'Helper changed: ' + relative)
    for role, filename in (('candidate', 'new'), ('baseline', 'base')):
        require(sha(WORK / 'engines' / filename) == validation[role + '_binary_sha256'], 'Engine binary changed: ' + role)
    require(sha(old.MANAGER) == validation['manager_sha256'], 'Manager changed')
    require(sha(old.BOOK) == validation['book_sha256'], 'Book changed')
    for role, path in (('config', WORK / 'config.json'), ('pgn', WORK / 'engines/sprt.pgn')):
        require(sha(path) == sha(artifacts[role]), 'Working input no longer equals interrupted prefix: ' + role)
    config = json.loads(artifacts['config'].read_bytes())
    expected = dict(wins=2, losses=6, draws=10, penta_WW=0, penta_WD=1, penta_WL=1, penta_DD=3, penta_LD=3, penta_LL=1)
    require(config['stats'] == {'new vs base': expected}, 'Original statistics differ')
    require(config['seed'] == 11194019307908266579 and config['concurrency'] == 5 and config['opening']['start'] == 1, 'Resume seed/schedule differs')
    require(config['pgn']['append_file'] is True and config['pgn']['file'] == 'engines/sprt.pgn', 'PGN append differs')
    require(config['config_name'] == 'config.json', 'Autosave path differs')
    require(config['sprt'] == dict(alpha=.05, beta=.05, elo0=-5.0, elo1=0.0, model='normalized', enabled=True), 'SPRT differs')
    own = []
    foreign = []
    for entry in Path('/proc').iterdir():
        if not entry.name.isdecimal():
            continue
        try:
            p = old.identity(int(entry.name))
            if p['state'] in ('Z', 'X'):
                continue
            if p['cwd'] == str(WORK) and p['exe'] in (str(old.MANAGER), str(WORK / 'engines/new'), str(WORK / 'engines/base')):
                own.append(p['pid'])
            if Path(p['exe']).name in ('dg-chesssi', 'fastchess', 'chesssi') and p['cwd'] != str(WORK):
                foreign.append({'pid': p['pid'], 'affinity': p['affinity'], 'name': Path(p['exe']).name})
                require(not (set(p['affinity']) & CPUS), 'Foreign chess workload overlaps Astra allocation')
        except (FileNotFoundError, PermissionError, ProcessLookupError):
            continue
    require(not own, 'Own match process already exists')
    return old, validation, env, artifacts, config, foreign

def capture(env, validation, log, folder):
    args = [sys.executable, '-B', str(ROOT / 'scripts/research/snapshot_run.py'), 'capture',
        '--source-root', str(WORK), '--run-dir', str(WORK), '--output', str(OUT / folder),
        '--config', str(WORK / 'config.json'), '--pgn', str(WORK / 'engines/sprt.pgn'),
        '--log', str(log), '--binary', 'candidate=' + str(WORK / 'engines/new'),
        '--binary', 'baseline=' + str(WORK / 'engines/base'), '--baseline', BASE,
        '--label', 'RFP removal continued after external gaming interruption; ' + folder,
        '--read-limit-mib', '256', '--copy-limit-mib', '128']
    for relative in sorted(validation['source_files_sha256']):
        args += ['--source-file', relative]
    for name in ('resume.py', 'reconcile.py', 'test_reconcile.py'):
        args += ['--source-file', str((OUT / name).relative_to(WORK))]
    with (OUT / (folder + '-capture.log')).open('x') as f:
        rc = subprocess.run(args, env=env, cwd=WORK, stdout=f, stderr=subprocess.STDOUT).returncode
    require(rc == 0, 'Snapshot capture failed: ' + folder)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    old, validation, env, artifacts, initial_config, foreign = context()
    reconciler = load_module('resume_reconcile', OUT / 'reconcile.py')
    # Empty resumed input is deliberately not a terminal log; validate old prefix in unit tests.
    if not args.run:
        print(json.dumps({'status': 'preflight_passed', 'head': validation['head'], 'baseline': BASE,
            'completed_games': 18, 'seed_decimal': str(initial_config['seed']),
            'foreign_allocations': foreign, 'launch_performed': False}), flush=True)
        return 0
    observation = json.loads((OUT / 'fresh-main-observation.json').read_bytes())
    observed = dt.datetime.fromisoformat(observation['observed_utc'])
    age = (dt.datetime.now(dt.timezone.utc) - observed).total_seconds()
    require(observation['sha'] == BASE and observed.tzinfo and 0 <= age <= 300, 'Accepted main observation stale or changed')
    output_names = ('launch-plan.json', 'initial-config.json', 'startup.json', 'runner-identity.json',
        'resume-raw.log', 'terminal-state.json', 'raw-terminal-snapshot', 'logical-terminal-snapshot',
        'logical.log', 'reconciliation.json', 'terminal-audit', 'result.json')
    for name in output_names:
        require(not (OUT / name).exists(), 'Continuation output already exists: ' + name)
    pinned = {str(OUT / n): sha(OUT / n) for n in ('resume.py', 'reconcile.py', 'test_reconcile.py')}
    pinned.update({str(ROOT / n): digest for n, digest in validation['helper_sha256'].items()})
    pinned.update({str(WORK / n): digest for n, digest in validation['source_files_sha256'].items()})
    pinned.update({str(WORK / 'engines' / n): validation[role + '_binary_sha256'] for role, n in (('candidate','new'),('baseline','base'))})
    pinned[str(old.MANAGER)] = validation['manager_sha256']
    pinned[str(old.BOOK)] = validation['book_sha256']
    pinned.update({str(path): sha(path) for path in artifacts.values()})
    pinned[str(OLD / 'launch-plan.json')] = sha(OLD / 'launch-plan.json')
    pinned[str(OLD / 'run_match.py')] = sha(OLD / 'run_match.py')
    def unchanged():
        for name, digest in pinned.items():
            require(sha(name) == digest, 'Input drift: ' + name)
        require(sha(OLD / 'terminal-snapshot/manifest.json') == PREFIX_MANIFEST, 'Original archive manifest drift')
    copy_exact(artifacts['config'], OUT / 'initial-config.json')
    prefix = artifacts['pgn'].read_bytes()
    plan = {'created_utc': utc(), 'baseline': BASE, 'head': validation['head'], 'branch': validation['branch'],
        'original_manifest_sha256': PREFIX_MANIFEST, 'original_audit_sha256': PREFIX_AUDIT,
        'original_archive': str(OLD / 'terminal-snapshot'),
        'original_config_sha256': sha(artifacts['config']), 'original_log_sha256': sha(artifacts['log']),
        'pgn_prefix_sha256': hashlib.sha256(prefix).hexdigest(), 'pgn_prefix_bytes': len(prefix),
        'original_completed_ids': list(range(1,19)), 'original_abandoned_ids': list(range(19,24)),
        'seed_decimal': str(initial_config['seed']), 'affinity': sorted(CPUS), 'concurrency': 5,
        'foreign_allocations': foreign, 'fresh_main_observation': observation, 'pinned_sha256': pinned,
        'coordination_url': 'https://github.com/LupeHiguera/ChessSI/pull/2#issuecomment-6358481119',
        'original_launch_plan_sha256': sha(OLD / 'launch-plan.json'),
        'manager_source_commit': 'f618e34540f94f4719ad3817950618dabe441318',
        'stopping': 'Natural normalized SPRT [-5,0] decision or original200000-game cap; no wall deadline',
        'evidence_policy': 'Separate raw sessions; derived logical log and exact omission ledger; benchmark not assigned'}
    expected_argv = [str(old.MANAGER), '-config', 'file=config.json']
    plan['argv'] = ['taskset', '-c', '14-19', *expected_argv]
    write('launch-plan.json', plan)
    unchanged()
    require((WORK / 'config.json').read_bytes() == (OUT / 'initial-config.json').read_bytes(), 'Resume config changed before launch')
    require((WORK / 'engines/sprt.pgn').read_bytes() == prefix, 'PGN changed before launch')
    stop = []
    def requested(signum, frame):
        stop.append(signal.Signals(signum).name)
    signal.signal(signal.SIGINT, requested)
    signal.signal(signal.SIGTERM, requested)
    errors, sent, startup, manager = [], [], None, None
    with (OUT / 'resume-raw.log').open('xb') as log:
        child = subprocess.Popen(plan['argv'], cwd=WORK, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        pidfd = None
        try:
            write('runner-identity.json', {'collector': old.identity(os.getpid()), 'leader': old.identity(child.pid),
                'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip(), 'launch_plan_sha256': sha(OUT / 'launch-plan.json')})
            pidfd = os.pidfd_open(child.pid, 0)
            poller = select.poll()
            poller.register(pidfd, select.POLLIN)
        except BaseException:
            # Popen made a private session. Keep its leader unreaped until that
            # group is killed, including failures during monitoring setup.
            try:
                os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            child.wait(timeout=10)
            if pidfd is not None:
                os.close(pidfd)
            raise
        started = time.monotonic()
        last_check = 0.0
        try:
            while not poller.poll(500):
                if stop:
                    raise InterruptedError('Collector stop requested: ' + ','.join(stop))
                now = time.monotonic()
                if startup and now - last_check < 10:
                    continue
                last_check = now
                members = []
                for entry in old.group(child.pid):
                    if entry['state'] in ('Z','X'):
                        continue
                    try:
                        p = old.identity(entry['pid'])
                    except (FileNotFoundError, ProcessLookupError):
                        continue
                    require(set(p['affinity']) <= CPUS, 'Process left reserved CPU allocation')
                    members.append(p)
                managers = [p for p in members if p['exe'] == str(old.MANAGER)]
                engines = [p for p in members if p['exe'] in (str(WORK / 'engines/new'), str(WORK / 'engines/base'))]
                require(len(managers) <= 1 and len(engines) <= 10, 'Unexpected match process count')
                if managers:
                    manager = managers[0]
                    require(manager['argv'] == expected_argv and manager['cwd'] == str(WORK), 'Manager identity/argv mismatch')
                    require(set(manager['affinity']) == CPUS and sha(Path('/proc') / str(manager['pid']) / 'exe') == validation['manager_sha256'], 'Manager executable/affinity mismatch')
                if startup is None:
                    require(now - started < 60, 'Startup verification timed out')
                    if manager and {p['exe'] for p in engines} == {str(WORK / 'engines/new'), str(WORK / 'engines/base')}:
                        for p in engines:
                            role = 'candidate' if p['exe'].endswith('/new') else 'baseline'
                            require(sha(Path('/proc') / str(p['pid']) / 'exe') == validation[role + '_binary_sha256'], 'Running engine differs')
                        startup = {'observed_utc': utc(), 'manager': manager, 'engines': engines}
                        write('startup.json', startup)
                        print(json.dumps({'status': 'continuation_started', 'manager_pid': manager['pid'], 'inherited_games': 18, 'cpus': '14-19', 'concurrency': 5}), flush=True)
                # The running transcript may end mid-write. Inspect only its complete lines.
                raw = (OUT / 'resume-raw.log').read_bytes()
                for line in raw[:raw.rfind(b'\n')+1].decode('utf-8').splitlines():
                    m = re.match(r'^(?:Started|Finished) game (\d+)', line)
                    require(not m or int(m[1]) >= 19, 'Manager restarted a completed game')
                with (WORK / 'engines/sprt.pgn').open('rb') as f:
                    require(f.read(len(prefix)) == prefix, 'Manager rewrote PGN prefix')
        except BaseException as error:
            errors.append(type(error).__name__ + ': ' + str(error))
        finally:
            if errors and not poller.poll(0):
                try:
                    os.killpg(child.pid, signal.SIGINT)
                    sent.append('SIGINT')
                except ProcessLookupError:
                    pass
                poller.poll(30000)
            remaining = [p for p in old.group(child.pid) if p['pid'] != child.pid and p['state'] not in ('Z','X')]
            if remaining or not poller.poll(0):
                errors.append('Own match session required cleanup')
                for sig in (signal.SIGTERM, signal.SIGKILL):
                    try:
                        os.killpg(child.pid, sig)
                        sent.append(signal.Signals(sig).name)
                    except ProcessLookupError:
                        pass
                    until = time.monotonic() + 5
                    while time.monotonic() < until:
                        remaining = [p for p in old.group(child.pid) if p['pid'] != child.pid and p['state'] not in ('Z','X')]
                        if not remaining and poller.poll(0):
                            break
                        time.sleep(.1)
                    if not remaining and poller.poll(0):
                        break
            terminal = bool(poller.poll(0)) and not remaining
            code = child.wait() if terminal else None
            os.close(pidfd)
    ended = utc()
    outcome = {'ended_utc': ended, 'process_terminal': terminal, 'manager_exit_code': code, 'errors': errors,
        'signals_sent': sent, 'stop_requested': stop, 'remaining_own_processes': remaining,
        'benchmark_result': 'not_assigned', 'reported_hypothesis': None}
    try:
        require(terminal, 'Own process group not terminal')
        require(startup is not None, 'Startup was not verified')
        unchanged()
        require((WORK / 'engines/sprt.pgn').read_bytes().startswith(prefix), 'Final PGN prefix changed')
        capture(env, validation, OUT / 'resume-raw.log', 'raw-terminal-snapshot')
        logical, provenance = reconciler.reconcile(artifacts['log'].read_bytes().decode('utf-8'), (OUT / 'resume-raw.log').read_bytes().decode('utf-8'))
        with (OUT / 'logical.log').open('xb') as f:
            f.write(logical.encode('utf-8'))
        write('reconciliation.json', provenance)
        capture(env, validation, OUT / 'logical.log', 'logical-terminal-snapshot')
        final_config = json.loads((WORK / 'config.json').read_bytes())
        require({k:v for k,v in initial_config.items() if k != 'stats'} == {k:v for k,v in final_config.items() if k != 'stats'}, 'Final protocol/seed differs')
        state = {'status': 'archived', 'process_terminal': True, 'observed_end_utc': ended,
            'signal_sent': bool(sent) if code == 0 or sent else None, 'binary_drift': False,
            'final_binary_hashes': {role: sha(WORK / 'engines' / n) for role,n in (('candidate','new'),('baseline','base'))},
            'archive': str(OUT / 'logical-terminal-snapshot'), 'raw_archive': str(OUT / 'raw-terminal-snapshot'),
            'scope': 'Terminal second session; full experiment has prior external interruption; log is explicitly derived'}
        write('terminal-state.json', state)
        for name, toolargs, filename in (
            ('extract', [ROOT / 'scripts/research/extract_result.py', '--snapshot', OUT / 'logical-terminal-snapshot', '--terminal-state', OUT / 'terminal-state.json'], 'terminal-extraction.json'),
            ('audit', [ROOT / 'engines/qsearch-validation/audit_match.py', '--snapshot', OUT / 'logical-terminal-snapshot', '--output', OUT / 'terminal-audit'], 'terminal-audit.log')):
            with (OUT / filename).open('x') as f:
                completed = subprocess.run([sys.executable, '-B', *map(str, toolargs)], cwd=WORK, env=env, stdout=f, stderr=subprocess.STDOUT)
            outcome[name + '_exit_code'] = completed.returncode
        extracted = json.loads((OUT / 'terminal-extraction.json').read_bytes())
        audited = json.loads((OUT / 'terminal-audit/result.json').read_bytes())
        require(audited['snapshot_manifest_sha256'] == extracted['manifest_sha256'], 'Audit/extraction archives differ')
        require(audited['audited_artifact_sha256'] == {n: extracted['artifact_sha256'][n] for n in ('log','pgn','config')}, 'Audit/extraction inputs differ')
        outcome['final_accounting'] = reconciler.validate_final(audited, extracted['log_evidence'])
        pgn_games = json.loads((OUT / 'terminal-audit/pgn-games.json').read_bytes())
        outcome['six_counters'] = reconciler.validate_six_counters(final_config['stats']['new vs base'], pgn_games)
        outcome['reported_hypothesis'] = extracted['log_evidence']['reported_hypothesis']
        require(code == 0 and not errors and outcome['extract_exit_code'] == outcome['audit_exit_code'] == 0, 'Terminal decision remains unresolved')
        require(extracted['evidence_status'] == 'ready_for_independent_audit', 'Extraction unresolved')
        unchanged()
        outcome['evidence_status'] = 'ready_for_continuation_review'
    except BaseException as error:
        errors.append(type(error).__name__ + ': ' + str(error))
        outcome['evidence_status'] = 'unresolved'
    write('result.json', outcome)
    print(json.dumps(outcome, indent=2), flush=True)
    return 0 if outcome['evidence_status'] == 'ready_for_continuation_review' else 2

if __name__ == '__main__':
    raise SystemExit(main())
