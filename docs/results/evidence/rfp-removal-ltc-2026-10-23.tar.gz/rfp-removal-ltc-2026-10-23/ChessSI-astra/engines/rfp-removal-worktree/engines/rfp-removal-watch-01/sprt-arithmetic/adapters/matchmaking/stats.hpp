#pragma once
// Data-only adapter. Field types/names/defaults match the pinned Stats header.
// getLLR reads only these fields; no tournament, JSON, chess or logging runtime.
namespace fastchess {
class Stats {
public:
 int wins=0,losses=0,draws=0;
 int penta_WW=0,penta_WD=0,penta_WL=0,penta_DD=0,penta_LD=0,penta_LL=0;
};
}
