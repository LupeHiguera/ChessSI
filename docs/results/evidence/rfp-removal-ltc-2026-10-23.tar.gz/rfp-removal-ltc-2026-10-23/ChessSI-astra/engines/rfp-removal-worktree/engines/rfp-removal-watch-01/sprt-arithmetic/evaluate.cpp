#include <matchmaking/sprt/sprt.hpp>
#include <matchmaking/stats.hpp>
#include <array>
#include <charconv>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <string_view>
int main(int argc,char** argv) {
    if(argc!=7) { std::cerr<<"Expected LL LD WL DD WD WW\n"; return 2; }
    std::array<int,6> c{};
    long long pairs=0;
    for(int i=0;i<6;i++) {
        std::string_view v(argv[i+1]);
        auto [ptr,ec]=std::from_chars(v.data(),v.data()+v.size(),c[i]);
        if(ec!=std::errc{} || ptr!=v.data()+v.size() || c[i]<0 || c[i]>100000) return 2;
        pairs+=c[i];
    }
    if(pairs<=0 || pairs>100000) return 2;
    fastchess::Stats s;
    s.penta_LL=c[0]; s.penta_LD=c[1]; s.penta_WL=c[2]; s.penta_DD=c[3]; s.penta_WD=c[4]; s.penta_WW=c[5];
    s.wins=2*c[5]+c[4]+c[2]; s.losses=2*c[0]+c[1]+c[2]; s.draws=c[1]+c[4]+2*c[3];
    fastchess::SPRT test(.05,.05,-5,0,"normalized",true);
    const double llr=test.getLLR(s,true);
    if(!std::isfinite(llr)) { std::cerr<<"Nonfinite LLR\n"; return 3; }
    const auto result=test.getResult(llr);
    const char* verdict=result==fastchess::SPRT_H0?"H0":result==fastchess::SPRT_H1?"H1":"CONTINUE";
    std::cout<<std::setprecision(17)
      <<"{\"pairs\":"<<pairs<<",\"games\":"<<2*pairs<<",\"wins\":"<<s.wins<<",\"losses\":"<<s.losses<<",\"draws\":"<<s.draws
      <<",\"llr\":"<<llr<<",\"lower\":"<<test.getLowerBound()<<",\"upper\":"<<test.getUpperBound()
      <<",\"decision\":\""<<verdict<<"\",\"scope\":\"Pinned-source arithmetic reproduction; not the installed manager binary\"}\n";
}
