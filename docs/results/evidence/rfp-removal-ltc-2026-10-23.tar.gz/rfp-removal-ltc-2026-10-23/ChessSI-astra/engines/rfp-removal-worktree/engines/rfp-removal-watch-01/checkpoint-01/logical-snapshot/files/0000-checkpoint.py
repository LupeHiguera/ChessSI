#!/usr/bin/env python3
"""One read-only live checkpoint; no signal, restart, or benchmark decision."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys

WORK=Path('/mnt/c/Users/Lupe/CLionProjects/ChessSI-astra/engines/rfp-removal-worktree')
WATCH=WORK/'engines/rfp-removal-watch-01'
RESUME=WORK/'engines/rfp-removal-resume-01'
OLD=WORK/'engines/rfp-removal-validation'
OUT=WATCH/'checkpoint-01'
def require(ok,why):
    if not ok: raise RuntimeError(str(why))
def load(name,path):
    m=importlib.util.module_from_spec(importlib.util.spec_from_file_location(name,path))
    sys.modules[name]=m
    exec(compile(path.read_bytes(),str(path),'exec'),m.__dict__)
    return m
def write(name,value):
    with (OUT/name).open('x') as f: json.dump(value,f,indent=2)
require(os.sched_getaffinity(0)=={19} and sys.flags.optimize==0,'CPU19 unoptimized Python required')
observer=load('checkpoint_observer',WATCH/'watch.py')
attachment=json.loads((WATCH/'attachment.json').read_bytes())
require(observer.sha(WATCH/'watch.py')==attachment['observer_sha256'],'Observer changed')
plan=json.loads((RESUME/'launch-plan.json').read_bytes())
require(observer.sha(RESUME/'launch-plan.json')==attachment['resume_launch_plan_sha256'],'Plan changed')
for path,digest in plan['pinned_sha256'].items():
    require(observer.sha(path)==digest,'Input drift: '+path)
identity=load('checkpoint_identity',OLD/'run_match.py')
current=identity.identity(10954)
require(current['start_ticks']=='73878' and current['state'] not in ('Z','X') and current['affinity']==list(range(14,20)),'Manager no longer same live process')
OUT.mkdir(exist_ok=False)
write('observed-live-manager.json',current)
observer.OUT=OUT
observer.capture(RESUME/'resume-raw.log','raw-snapshot',plan)
raw=observer.archive_roles(OUT/'raw-snapshot')
original=observer.archive_roles(OLD/'terminal-snapshot')
old_bytes=original['log'].read_bytes()
new_bytes=raw['log'].read_bytes()
require(hashlib.sha256(old_bytes).hexdigest()==plan['original_log_sha256'],'Original log identity differs')
require(new_bytes.endswith(b'\n'),'Live log partial final line')
require(not re.search(rb'^SPRT \(',new_bytes,re.M),'Terminal decision arrived; use terminal review instead')
lines=old_bytes.decode('utf-8').splitlines(keepends=True)
omissions={37:'Started game 19 ',39:'Started game 20 ',41:'Started game 21 ',43:'Started game 22 ',45:'Started game 23 ',
    46:'Tournament was interrupted.',47:'Finished match',48:'Total Time:'}
removed=[]
for number,prefix in omissions.items():
    require(lines[number-1].startswith(prefix),'Original omission differs')
    removed.append({'line_number':number,'text':lines[number-1]})
derived=''.join(line for n,line in enumerate(lines,1) if n not in omissions).encode('utf-8')+new_bytes
with (OUT/'logical-live.log').open('xb') as f: f.write(derived)
write('projection.json',{'scope':'Interim two-session accounting projection; no terminal marker added and no verdict assigned',
    'original_log_sha256':hashlib.sha256(old_bytes).hexdigest(),'resumed_snapshot_log_sha256':hashlib.sha256(new_bytes).hexdigest(),
    'derived_sha256':hashlib.sha256(derived).hexdigest(),'omitted_old_lines':removed,'benchmark_result':'not_assigned'})
snap=load('checkpoint_snapshot',observer.ROOT/'scripts/research/snapshot_run.py')
snap.create_snapshot(OUT/'logical-snapshot',WORK,WORK,config=raw['config'],log=OUT/'logical-live.log',
    pgn=raw['pgn'],binaries=[('candidate',raw['binary_path:candidate']),('baseline',raw['binary_path:baseline'])],
    source_files=[str(Path(__file__).relative_to(WORK))],label='Live continuation prefix; never a terminal result',baseline=plan['baseline'])
projected=observer.archive_roles(OUT/'logical-snapshot')
for role in ('config','pgn','binary_path:candidate','binary_path:baseline'):
    require(observer.sha(raw[role])==observer.sha(projected[role]),'Raw/projected mismatch: '+role)
require(raw['pgn'].read_bytes().startswith(original['pgn'].read_bytes()),'Original PGN bytes changed')
with (OUT/'audit.log').open('x') as f:
    rc=subprocess.run([sys.executable,'-B',str(observer.ROOT/'engines/qsearch-validation/audit_match.py'),
        '--snapshot',str(OUT/'logical-snapshot'),'--output',str(OUT/'audit')],
        cwd=WORK,env=observer.env(),stdout=f,stderr=subprocess.STDOUT).returncode
require(rc==0,'Live prefix auditor failed; inspect evidence')
result=json.loads((OUT/'audit/result.json').read_bytes())
require(not result['log_report_count_mismatches'] and not result['suspect_termination_reasons'],'Live evidence discrepancy')
write('result.json',{'scope':'Verified live checkpoint only; autosave can lag completed games',
    'manager_pid':10954,'manager_start_ticks':'73878','audit_exit_code':rc,
    'pgn_games':result['pgn_games_legally_replayed'],'log_finished_games':result['log_finished_games'],
    'legal_plies':result['legal_plies'],'reports_checked':result['log_reports_checked'],
    'paired_counts':result['log_pair_aggregate'],'config_counts':result['config_counts'],
    'log_games_missing_from_pgn':result['log_games_not_in_pgn_snapshot'],
    'pgn_games_missing_from_log':result['pgn_games_not_in_log_snapshot'],
    'audit_sha256':observer.sha(OUT/'audit/result.json'),'benchmark_result':'not_assigned'})
print((OUT/'result.json').read_text(),flush=True)
