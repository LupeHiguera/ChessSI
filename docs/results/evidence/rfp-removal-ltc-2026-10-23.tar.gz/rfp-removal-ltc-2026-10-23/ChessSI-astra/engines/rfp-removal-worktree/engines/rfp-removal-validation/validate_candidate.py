import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path('/mnt/c/Users/Lupe/CLionProjects/ChessSI-astra/engines/rfp-removal-worktree')
OUT = ROOT / 'engines/rfp-removal-validation'
os.chdir(ROOT)
assert set(os.sched_getaffinity(0)) == set(range(14,20))
env = dict(os.environ, GIT_DIR='/mnt/c/Users/Lupe/CLionProjects/ChessSI/.git/worktrees/rfp-removal-worktree', GIT_WORK_TREE=str(ROOT))
source_diff = subprocess.check_output(['git','diff','684badce8f16057b71afc044228c18dd91b6223e','--','src'], env=env)
assert not source_diff, 'Removal changed something beyond the exact RFP addition'
for name in ('baseline','candidate'):
    log = (OUT/(name+'-test.log')).read_text()
    assert '35 passed, 0 failed' in log and '17 passed, 0 failed' in log
    assert not re.search(r'^FAIL ',log,re.M)
assert (OUT/'baseline-bench.txt').read_text().strip().splitlines()[-1].split()[0] == '276006'
assert (OUT/'candidate-bench.txt').read_text().strip().splitlines()[-1].split()[0] == '358129'
command = ['make','-j6','EXE=engines/rfp-removal-validation/sanitize',
           'CXXFLAGS=-std=c++20 -O1 -g -fsanitize=address,undefined -Wall -Wextra',
           'engines/rfp-removal-validation/sanitize-rfp-tests']
with (OUT/'sanitizer-01-build.log').open('x') as log:
    build = subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
if build.returncode:
    raise SystemExit(build.returncode)
with (OUT/'sanitizer-01-test.log').open('x') as log:
    test = subprocess.run([str(OUT/'sanitize-rfp-tests')],env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:abort_on_error=1'),stdout=log,stderr=subprocess.STDOUT)
record = {'created_utc':dt.datetime.now(dt.timezone.utc).isoformat(),
          'baseline':'afe9aab6002ccf7e878d5622f86870383e301fb3',
          'candidate_src_equals':'684badce8f16057b71afc044228c18dd91b6223e',
          'baseline_bench':276006,'candidate_bench':358129,
          'baseline_perft':35,'baseline_boundaries':17,'candidate_perft':35,'candidate_boundaries':17,
          'sanitizer_build_command':command,'sanitizer_build_exit':build.returncode,'sanitizer_exit':test.returncode,
          'initial_sanitizer_shell_attempt':'Compiler flags were lost by Windows to WSL shell quoting; this argument-list build supersedes that invalid attempt.',
          'affinity':sorted(os.sched_getaffinity(0))}
names = ['baseline-test.log','baseline-bench.txt','baseline-validated','candidate-test.log','candidate-bench.txt','candidate-validated','sanitizer-01-build.log','sanitizer-01-test.log','validate_candidate.py']
record['sha256'] = {p:hashlib.sha256((OUT/p).read_bytes()).hexdigest() for p in names}
record['sanitizer_passed'] = test.returncode == 0 and '17 passed, 0 failed' in (OUT/'sanitizer-01-test.log').read_text()
with (OUT/'validation.json').open('x') as f:
    json.dump(record,f,indent=2); f.write('\n')
print(json.dumps(record,indent=2),flush=True)
raise SystemExit(0 if record['sanitizer_passed'] else 1)
